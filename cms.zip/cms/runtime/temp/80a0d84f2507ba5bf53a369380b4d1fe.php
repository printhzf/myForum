<?php /*a:1:{s:70:"F:\wamp64\www\cms\application/index/view\authmanager\viewrulelist.html";i:1549719935;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
	    <meta name="renderer" content="webkit">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	    <title><?php echo htmlentities(app('config')->get('web_title')); ?>-角色权限列表</title>

	    <link rel="stylesheet" type="text/css" href="/static/css/buttons/buttons.css" />
    	<link rel="stylesheet" type="text/css" href="/static/fontawesome-5.6.3/css/all.css" />
	    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
	    <script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
	    <script type="text/javascript" src="/static/layui/layui.js"></script>

	    <style type="text/css">
	    	.main{
	    		height: 400px;
	    		margin: 10px 0 0 20px;
	    	}
	    	.margin-r10{
	    		width: 26px;
	    		height: 26px;
	    		margin-right: 10px;
	    	}
	    	.ok{
	    		font-size: 26px; 
	    		color: #1E9FFF;
	    	}
	    	.close{
	    		font-size: 26px; 
	    		color: #FF5722;
	    	}
	    </style>
	</head>
	<body>
		<script id="status" type="text/html" >
			{{#  if(d.status == '1'){ }}
				<i class="layui-icon layui-icon-ok ok"></i>
			{{#  } else { }}
				<i class="layui-icon layui-icon-close close"></i>
			{{#  } }}
		</script>
		<script id="toolbar_ruleList" type="text/html" >
			<div class="layui-btn-container">
				<button class="button button-plain button-border button-square button-caution button-small margin-r10" lay-event="createRole" title="添加角色">
					<i class="fa fa-plus"></i>
				</button>
				<button class="button button-plain button-border button-square button-royal button-small margin-r10" lay-event="editRole" title="编辑角色">
					<i class="fa fa-edit"></i>
				</button>
				<button class="button button-plain button-border button-square button-highlight button-small margin-r10" lay-event="deleteRole" title="删除角色">
					<i class="fa fa-trash"></i>
				</button>
			</div>
		</script>
		<div class="main">
			<table id="roleList" ></table>
 		</div>
		<script src="/layui/layui.js"></script>
		<script>
		var	option = {
				elem: '#roleList'
				,toolbar: '#toolbar_ruleList'
				,width: 1000
				,height: 400
				,even: true
				,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
				,url: '/index/Authmanager/getRuleList' //数据接口
				,page: true //开启分页
				,cols: [[ //表头
					{type: 'checkbox', fixed: 'left'}
					,{field: 'id', title: 'ID', width:80, sort: true, fixed: 'left'}
					,{field: 'title', title: '角色', width:80}
					,{field: 'rules', title: '权限'}
					,{field: 'status', title: '状态', width:80, sort: true, templet: '#status',}
				]]
			};
		layui.use('table', function(){
			var table = layui.table;
			var tableIns = table.render(option);
			// 工具栏事件
			table.on('toolbar(roleList)', function(obj){
				var checkStatus = table.checkStatus(obj.config.id);
				switch(obj.event){
					case 'createRole':
						var data = checkStatus.data;				
					break;
					case 'editRole':			
					break;
					case 'deleteRole':

					break;
				};
			});
		});
</script>
	</body>
</html>