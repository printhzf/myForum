<?php /*a:1:{s:70:"F:\wamp64\www\cms\application/index/view\usermanager\viewuserlist.html";i:1549251647;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
	    <meta name="renderer" content="webkit">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	    <title><?php echo htmlentities(app('config')->get('web_title')); ?>-用户列表</title>

	    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
	    <script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
	    <script type="text/javascript" src="/static/layui/layui.js"></script>
	    <style type="text/css">
	    	.main{
	    		height: 400px;
	    		margin: 10px 0 0 20px;
	    	}
	    </style>
	</head>
	<body>
		<div class="main">
			<table id="userList" ></table>
 		</div>
		<script src="/layui/layui.js"></script>
		<script>
		layui.use('table', function(){
			var table = layui.table;

			//第一个实例
			table.render({
				elem: '#userList'
				,width: 1000
				,height: 400
				,even: true
				,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
				,url: '/index/usermanager/getUserList' //数据接口
				,page: true //开启分页
				,cols: [[ //表头
					{field: 'id', title: 'ID', width:80, sort: true, fixed: 'left'}
					,{field: 'username', title: '用户名', width:80}
					,{field: 'email', title: '邮箱', width:160}
					,{field: 'gender', title: '性别', width:80, sort: true}
					,{field: 'last_login_ip', title: '上次登录IP', width: 135, sort: true}
					,{field: 'last_login_time', title: '上次登录时间', width: 170, sort: true}
				]]
			});

		});
</script>
	</body>
</html>