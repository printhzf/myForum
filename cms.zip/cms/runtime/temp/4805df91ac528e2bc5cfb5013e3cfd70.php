<?php /*a:1:{s:70:"F:\wamp64\www\cms\application/index/view\usermanager\viewregister.html";i:1548840350;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		
		<meta charset="UTF-8">
	    <meta name="renderer" content="webkit">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	    <title><?php echo htmlentities(app('config')->get('web_title')); ?>-注册页</title>
	    
	    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
	    <link rel="stylesheet" type="text/css" href="/static/frame/static/css/style.css" />
	    
	    <script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
	    <script type="text/javascript" src="/static/layui/layui.js"></script>

	</head>
	<body>
	    <!-- 表单选项 -->
	    <div class="login-main" style="width: 300px;padding: 0 20px 0 20px;">
		    <header class="layui-elip">注册页</header>
		    <form id="form_register" class="layui-form">
		        <!-- CSRF Token -->
		        <?php echo token(); ?>
		        <div class="layui-input-inline">
		            <input type="text" name="email" placeholder="邮箱" autocomplete="off" class="layui-input" value="<?php echo htmlentities((app('session')->get('register_email') ?: '')); ?>" lay-verify="required|email">
		        </div>
		        <div class="layui-input-inline">
		            <input type="text" name="username" placeholder="用户名" autocomplete="off" class="layui-input" value="<?php echo htmlentities((app('session')->get('register_name') ?: '')); ?>" lay-verify="required|username">
		        </div>
		        <div class="layui-input-inline">
		            <input type="password" name="password" placeholder="请输入密码" autocomplete="off" class="layui-input" value="<?php echo htmlentities((app('session')->get('register_pass') ?: '')); ?>" lay-verify="required|password" >
		        </div>
		                <div class="layui-input-inline">
		            <input type="password" name="resure" placeholder="再次输入密码" autocomplete="off" class="layui-input" > <!-- lay-verify="required" -->
		        </div>
		        <div class="layui-input-inline login-btn">
		            <button type="submit" class="layui-btn" lay-filter="add" lay-submit>注册</button>
		        </div>
		        <hr/>
		        <p>
		        	<a href="<?php echo url('index/usermanager/viewLogin'); ?>" class="fl">已有账号？立即登录</a>
		        	<a href="<?php echo url('index/index/index'); ?>" class="fr">回到首页</a>
		        </p>
		    </form>
		</div>
		<script type="text/javascript">
		    layui.use(['form','jquery','layer'], function () {
		        var form   = layui.form;
		        var $      = layui.jquery;
		        var layer  = layui.layer;
		        form.verify({
		            //支持函数式/数组的形式
		            username: function(value, item){ //value：表单的值、item：表单的DOM对象
		                if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
		                    return '用户名不能有特殊字符';
		                }
		                if(/(^\_)|(\__)|(\_+$)/.test(value)){
		                    return '用户名首尾不能出现下划线\'_\'';
		                }
		                if(new RegExp("^[\S]{6,12}$").test(value)){
		                    return '用户名必须6到16位，且不能出现空格';
		                }
		                if(/^\d+\d+\d$/.test(value)){
		                    return '用户名不能全为数字';
		                }
		            }
		            //数组的两个值分别代表：[正则匹配、匹配不符时的提示文字]
		            ,password: [
		                /^[\S]{6,16}$/
		                ,'密码必须6到16位，且不能出现空格'
		            ] 
		        });      
		        //添加表单监听事件,提交注册信息
		        form.on('submit(add)', function() {
		        	var data = $("#form_register").serialize();
		            $.ajax({
		                url    : 'create',
		                type   : 'post',
		                data   :  data,
		                success: function(res){
		                	console.log(res);return;
		                    if (res.code == 200) {
		                        layer.msg(res.msg);
		                        $(":input","#form_register").val("");
		                    }else {
		                        layer.msg(res.msg);
		                        setTimeout( function(){
		                        	window.location.reload()
		                        },1000);
		                    }
		                }
		            })
		            //防止页面跳转
		            return false;
		        });
		 
		    });	
		</script>
	</body>
</html>