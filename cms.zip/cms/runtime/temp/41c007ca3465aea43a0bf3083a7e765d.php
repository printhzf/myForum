<?php /*a:1:{s:73:"F:\wamp64\www\cms\application/index/view\filemanager\viewFileManager.html";i:1549251632;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>文件管理</title>
    <link rel="stylesheet" type="text/css" href="/static/css/buttons/buttons.css" />
    <link rel="stylesheet" type="text/css" href="/static/fontawesome-5.6.3/css/all.css" />
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="/static/layui/layui.js"></script>
    <style type="text/css">
    	.main{
    		height: 400px;
    		margin: 10px 0 0 20px;
    	}
    	.margin-r10{
    		width: 26px;
    		height: 26px;
    		margin-right: 10px;
    	}
    	.ok{
    		font-size: 26px; 
    		color: #1E9FFF;
    	}
    	.close{
    		font-size: 26px; 
    		color: #FF5722;
    	}
    </style>

</head>

<body>
	<div class="main">
		<input id="backDir" type="hidden" value="<?php echo htmlentities($backDir); ?>">
		<input id="dirname" type="hidden" value="<?php echo htmlentities($dirname); ?>">
		<table id="table_files" class="layui-hide" lay-filter="table_files"></table>
		<script id="filetype" type="text/html" >
			{{#  if(d.filetype == 'dir'){ }}
				<i class="fa fa-folder-open" ></i>
			{{#  } else { }}
				<i class="fa fa-file"></i>
			{{#  } }}
		</script>
		<script id="is_readable" type="text/html" >
			{{#  if(d.is_readable == 'yes'){ }}
				<i class="layui-icon layui-icon-ok ok" ></i>
			{{#  } else { }}
				<i class="layui-icon layui-icon-close close"></i>
			{{#  } }}
		</script>
		<script id="is_writeable" type="text/html" >
			{{#  if(d.is_writeable == 'yes'){ }}
				<i class="layui-icon layui-icon-ok ok"></i>
			{{#  } else { }}
				<i class="layui-icon layui-icon-close close"></i>
			{{#  } }}
		</script>
		<script id="is_executable" type="text/html" >
			{{#  if(d.is_executable == 'yes'){ }}
				<i class="layui-icon layui-icon-ok ok"></i>
			{{#  } else { }}
				<i class="layui-icon layui-icon-close close"></i>
			{{#  } }}
		</script>
		<script id="toolbar_files" type="text/html" >
			<div class="layui-btn-container">
				<button class="button button-plain button-border button-square button-caution button-small margin-r10" lay-event="createFile" title="创建文件">
					<i class="fa fa-file"></i>
				</button>
				<button class="button button-plain button-border button-square button-royal button-small margin-r10" lay-event="uploadeFile" title="上传文件">
					<i class="fa fa-upload"></i>
				</button>
				<a href="/index/filemanager/index?path=<?php echo htmlentities($backDir); ?>" class="button button-plain button-border button-square button-highlight button-small margin-r10" lay-event="back" title="返回上级">
					<i class="fa fa-arrow-left"></i>
				</a>
				
			</div>
		</script>
		<script id="tool_files" type="text/html">
			
			{{#  if(d.filetype == 'file'){ }}
				<a class="layui-btn layui-btn-primary layui-btn-xs" lay-event="view" title="查看"><i class="fa fa-eye"></i></a>
	    		<a class="layui-btn layui-btn-xs" lay-event="edit" title="编辑"><i class="fa fa-edit"></i></a>
			{{#  } else { }}
				<a href="/index/filemanager/index?path=<?php echo htmlentities($dirname); ?>/{{d.filename}}" class="layui-btn layui-btn-primary layui-btn-xs" title="查看"><i class="fa fa-eye"></i></a>
			{{#  } }}
			<a class="layui-btn layui-btn-xs" lay-event="rename" title="重命名"><i class="fa fa-tag"></i></a>
			<a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="copy" title="复制"><i class="fa fa-copy"></i></a>
			<a class="layui-btn layui-btn-warm layui-btn-xs" lay-event="cut" title="剪切"><i class="fa fa-cut"></i></a>
			{{#  if(d.filetype == 'file'){ }}
				<a href="/index/filemanager/downloadFile?filename=<?php echo htmlentities($dirname); ?>/{{d.filename}}"  class="layui-btn layui-bg-cyan layui-btn-xs" title="下載">
					<i class="fa fa-download"></i>
				</a>
			{{#  } else { }}
			{{#  } }}
			<a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del" title="删除"><i class="fa fa-trash"></i></a>
		</script>
	</div>
</body>
<script>
var dirname= $("#dirname").val();
var url = '/index/filemanager/getTableData?path='+dirname;
var option = {
	elem: '#table_files'
	,url: url
	,toolbar: '#toolbar_files'
	,width: 1080
	,height: 400
	,even: true
	,cellMinWidth: 80 //全局定义常规单元格的最小宽度，layui 2.2.1 新增
	,cols: [[
		{type: 'checkbox', fixed: 'left'}
		,{field:'id', title: 'ID', fixed: 'left', sort: true, width: 72}
		,{field:'filename', title: '文件名', sort: true, width: 140}
		,{field:'filetype', title: '文件类型', templet: '#filetype', sort: true, width: 100}
		,{field:'size', title: '文件大小', sort: true, width: 100}
		,{field:'is_readable', title: '可读', templet: '#is_readable', sort: true, width: 70 }
		,{field:'is_writeable', title: '可写', templet: '#is_writeable', sort: true, width: 70}
		,{field:'is_executable', title: '可执行', templet: '#is_executable', sort: true, width: 80}
		,{field:'gmt_create', title: '创建时间', sort: true, width: 160}
		,{field:'gmt_modified', title: '修改时间', sort: true, hide: true, width: 160}
		,{field:'gmt_visited', title: '访问时间', sort: true, hide: true, width: 160}
		,{fixed: 'right', title:'操作', toolbar: '#tool_files', width:280}
	]]
	,page: true
};
layui.use('table', function(){
	var table = layui.table;
	var tableIns = table.render(option);
	// 工具栏事件
	table.on('toolbar(table_files)', function(obj){
		var checkStatus = table.checkStatus(obj.config.id);
		switch(obj.event){
			case 'createFile':
				var data = checkStatus.data;				
				createFile(data);
			break;
			case 'uploadeFile':			
				viewUploadeFile();
			break;
			case 'back':
				var data = checkStatus.data;
			break;
		};
	});

	//监听行工具事件
	table.on('tool(table_files)', function(obj){
		var data = obj.data;
		switch(obj.event)
		{
			case 'view' :
				getFileContent(data);
			break;
			case 'edit' :		
			// layer.prompt({
			// 	formType: 2
			// 	,value: data.email
			// }, function(value, index){
			// 	obj.update({
			// 		email: value
			// 	});
			// 	layer.close(index);
			// });
				viweUpdateFile(data);
			break;
			case 'rename' :
				viewRenameFile(data);
			break;
			case 'copy' :
				viewCopyFile(data);
			break;
			case 'cut' :

			break;
			case 'del' :
				layer.confirm('真的删除行么', function(index){
					deleteFunc(data);
					obj.del();
					layer.close(index);
				});
			break;
		}
	});
});

function viewUploadeFile(){
	layer.open({
		type: 2,
		skin: 'layui-layer-rim', //加上边框
		area: ['600px', '400px'], //宽高
		title: '上传文件',
		anim: 2,
		content: ['viewUploadFile'], //iframe的url，no代表不显示滚动条

	});
}

function viewCopyFile(data) {
	var filename = "'"+dirname+'/'+data['filename']+"'";
	var html = '<div style="text-align:center;padding:10px;"><form class="layui-form layui-form-pane" action=""><div class="layui-form-item"><label class="layui-form-label">复制至</label><div class="layui-input-block"><input name="toDirName" type="text" autocomplete="off" placeholder="请输入文件夹名" class="layui-input"></div></div></form><button class="button button-3d button-primary button-rounded" onclick="copyFile('+filename+')">保存</button></div>';
	layer.open({
		type: 1,
		skin: 'layui-layer-rim', //加上边框
		area: ['420px', '180px'], //宽高
		title: '复制文件',
		content: html
	});
}

function copyFile(filename){

	var dirname = $('input[name=toDirName]').val();
	$.ajax({
		type: 'POST',
		url : '/index/filemanager/copyFile',
		data: { path: path, dirname: dirname },
		success: function(res){
			layer.msg(res.msg);
			if (res.code == 200) {
				setTimeout(function(){
					layer.closeAll();
					layui.table.reload('table_files', option);
				}, "1000");
			}
		}
	});
		
}

function back() {

}

function createFile(data) {
	var html = '<div style="text-align:center;padding:10px;"><form class="layui-form layui-form-pane" action=""><div class="layui-form-item"><label class="layui-form-label">文件名</label><div class="layui-input-block"><input name="newfilename" type="text" autocomplete="off" placeholder="请输入文件名" class="layui-input"></div></div></form><button class="button button-3d button-primary button-rounded" onclick="save()">保存</button></div>';
	layer.open({
		type: 1,
		skin: 'layui-layer-rim', //加上边框
		area: ['420px', '180px'], //宽高
		title: '创建文件',
		content: html
	});
}

function save(){
	var filename = $('input[name=newfilename]').val();
	var pattern_chin = /[、,;；，《》\*\?\/\|]+/;
	if (filename != '') {
		var matchResult = filename.match(pattern_chin);
		if (matchResult == null) {
			var path = dirname+'/'+filename;
			$.ajax({
				type: 'POST',
				url : '/index/filemanager/createFile',
				data: { path: path },
				success: function(res){
					layer.msg(res.msg);
					if (res.code == 200) {
						setTimeout(function(){
							layer.closeAll();
							layui.table.reload('table_files', option);
						}, "1000");
					}
				}
			});
		} else {
			layer.msg('文件名不能含有以下非法字符,;；，《》*?/|');
		}
	}
	
}


function getFileContent(data) {
	var path = dirname+'/'+data['filename'];
	$.ajax({
		type: 'POST',
		url : '/index/filemanager/getFileContent',
		data: { path: path },
		success: function(res){
			if (res.code == 200) {
				layer.open({
					type: 1,
					title: data['filename'],
					skin: 'layui-layer-rim', //加上边框
					area: ['500px', '300px'], //宽高
					content: res.msg
				});
			} else {
				layer.msg(res.msg);
			}
		}
	});
}

function viewRenameFile(data) {
	var filename = "'"+data['filename']+"'";
	var name = '';
	if (data['filetype'] == 'dir'){
		name = '目录名';
	} else {
		name = '文件名'; 
	}
	var html = '<div style="text-align:center;padding:10px;"><form class="layui-form layui-form-pane" action=""><div class="layui-form-item"><label class="layui-form-label">'+name+'</label><div class="layui-input-block"><input name="newfilename" type="text" autocomplete="off" placeholder="请输入'+name+'" class="layui-input"></div></div></form><button class="button button-3d button-primary button-rounded" onclick="renameFunc('+filename+')">保存</button></div>';
	layer.open({
		type: 1,
		skin: 'layui-layer-rim', //加上边框
		area: ['420px', '180px'], //宽高
		title: data['filename'],
		content: html
	});
}

function renameFunc(filename) {
	var path = dirname+'/'+filename;
	var newName = $('input[name=newfilename]').val();
	$.ajax({
		type: 'POST',
		url : '/index/filemanager/renameFunc',
		data: { path: path , name: newName},
		success: function(res){
			layer.msg(res.msg);
			if (res.code == 200) {
				setTimeout(function(){
					layer.closeAll();
					layui.table.reload('table_files', option);
				}, "1000");
			}
		}
	});
}

function viweUpdateFile(data) {
	var path = dirname+'/'+data['filename'];
	$.ajax({
		type: 'POST',
		url : '/index/filemanager/viweUpdateFile',
		data: { path: path },
		success: function(res){
			layer.open({
				type: 1,
				title: data['filename'],
				skin: 'layui-layer-rim', //加上边框
				area: ['500px', '300px'], //宽高
				content: res
			});
		}
	});
}

function updateFile() {
	var path = $('input[name=path]').val();
	var content = $('textarea[name=newFileContent]').val();
	$.ajax({
		type: 'POST',
		url : '/index/filemanager/updateFile',
		data: { path: path, content: content },
		success: function(res){
			if (res) {
				layer.msg(res.msg);	
			}
		}
	});
}

function downloadFile(data) {
	var url = '/index/filemanager/downloadFile';
    var filename = dirname+'/'+data['filename'];
    var form = $("<form></form>").attr("action", url).attr("method", "post");
    form.append($("<input></input>").attr("type", "hidden").attr("name", "filename").attr("value", filename));
    form.appendTo('body').submit().remove();
}

function deleteFunc(data) {
	var path = dirname+'/'+data['filename'];
	$.ajax({
		type: 'POST',
		url : '/index/filemanager/deleteFunc',
		data: { path: path },
		success: function(res){
			layer.msg(res.msg);
		}
	});
}
</script>
</html>