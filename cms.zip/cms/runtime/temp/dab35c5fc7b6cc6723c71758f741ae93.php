<?php /*a:1:{s:57:"F:\wamp64\www\cms\application/index/view\index\index.html";i:1550229205;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
	    <meta name="renderer" content="webkit">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	    <title><?php echo htmlentities(app('config')->get('web_title')); ?>-首页</title>
	    <link rel="stylesheet" type="text/css" href="/static/fontawesome-5.6.3/css/all.css" />
	    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
<style type="text/css">
	.layui-header{display: flex;justify-content: flex-start;}
	.layui-header ul{background: white;}
	.layui-nav-item a{color: black;}
	.layui-header i{display: inline-block;padding: 0 20px 0 20px;color: black;text-align: center;cursor: pointer;}
	#cmsIcon{width: 200px;height:60px;background: #393D49;color: white;line-height: 60px;}
	/*#cmsIcon img{width: 200px;height: 60px;}*/
	#cmsIcon img{width: 30px;height: 30px;border-radius: 50%;margin-left: 20px}
	#cmsIcon span{font-style: italic}
	.rightmenu{font-size:12px; padding:5px 10px; border-radius: 2px;margin-top: 60px}
	.rightmenu li{line-height:20px; cursor: pointer;}
	ul.layui-tab-title li:first-child i{display:none;}
</style>

	</head>
	<body>
	<!-- 头部导航 -->
	<div class="layui-header">
		<div id="cmsIcon">
			<!-- 默认首页高亮显示-->
			<!-- <img src="/static/images/logo.png" /> -->
			<img src="/static/images/logo3.png" /> 
			<span><b>CMS</b></span>
		</div>
		<div id="topMenu">
		<ul class="layui-nav layui-layout-left" style="background: white;">
			<li class="layui-nav-item layadmin-flexible" lay-unselect="">
				<i class="layui-icon layui-icon-shrink-right" id="flexibleBtn" title="折叠"></i>
			</li>
			<li class="layui-nav-item layadmin-flexible" lay-unselect="">
				<i class="layui-icon layui-icon-refresh-3" id="refreshBtn" title="刷新" ></i>
			</li>
		</ul>
		<ul class="layui-nav layui-layout-right">
			<li class="layui-nav-item">
				<?php if(empty(app('session')->get('userId')) || ((app('session')->get('userId') instanceof \think\Collection || app('session')->get('userId') instanceof \think\Paginator ) && app('session')->get('userId')->isEmpty())): ?>
					<a href="<?php echo url('/index/Usermanager/viewLogin'); ?>" style="color: #000;">登录</a>
				<?php else: if(app('session')->get('userNc') != '0'): ?>
					<span class="layui-badge" title="未读消息" style="cursor: pointer;">
						<?php echo htmlentities(app('session')->get('userNc')); ?>
					</span>
					<?php endif; ?>
					<a href="#" style="margin-left: 10px;">
						<?php if(empty(app('session')->get('headImg')) || ((app('session')->get('headImg') instanceof \think\Collection || app('session')->get('headImg') instanceof \think\Paginator ) && app('session')->get('headImg')->isEmpty())): ?>
							<img src="/static/images/user/headimg.jpg" class="layui-nav-img"/>
						<?php else: ?>
							<img src="<?php echo htmlentities(app('session')->get('headImg')); ?>" class="layui-nav-img"/>
						<?php endif; ?>
						<?php echo htmlentities(app('session')->get('userName')); ?>
					</a>
					<!-- 跳转到后台的管理中心 -->
		            <dl class="layui-nav-child">
		            	<dd><a href="<?php echo url('/index/Usermanager/viewNotification',['user_id'=> app('session')->get('userId')]); ?>">未读消息</a></dd>
		            	<dd><a href="<?php echo url('/index/Usermanager/viewUserInfo',['user_id'=> app('session')->get('userId')]); ?>">管理中心</a></dd>
		            	<dd><a href="<?php echo url('/index/Usermanager/logout'); ?>" >退出登录</a></dd>
		        	</dl>
				<?php endif; ?>
			</li>
		</ul>
		</div>
	</div>
	<!-- 侧边导航 -->
	<ul class="layui-nav layui-nav-tree layui-nav-side" lay-filter="treenav" style="margin-top:60px"> 
	    <li class="layui-nav-item">
	    	<a href="javascript:;"><i class="fa fa-cog"> 应用管理</i></a>
	    	<dl class="layui-nav-child">
	            <dd><a href="javascript:;" class="site-url" data-title="论坛" data-id="1" data-url="">论坛</a></dd>
	        </dl>
	    </li>
	    <li class="layui-nav-item">
	        <a href="javascript:;"><i class="fa fa-users"> 用户管理</i></a>
	        <dl class="layui-nav-child">
	            <dd><a href="javascript:;" class="site-url" data-title="网站用户" data-id="3" data-url="<?php echo url('index/Usermanager/viewUserList'); ?>">网站用户</a></dd>
	            <dd><a href="javascript:;" class="site-url" data-title="后台管理员" data-id="4" data-url="">后台管理员</a></dd>
	        </dl>
	    </li>
	    <li class="layui-nav-item">
	    	<a href="javascript:;" class="site-url" data-title="权限管理"><i class="fa fa-ban"> 权限管理</i></a>
	    	<dl class="layui-nav-child">
	            <dd><a href="javascript:;" class="site-url" data-title="管理员列表" data-id="5" data-url="<?php echo url('index/Authmanager/viewGroupAcess'); ?>">管理员列表</a></dd>
	            <dd><a href="javascript:;" class="site-url" data-title="角色列表" data-id="6" data-url="<?php echo url('index/Authmanager/viewRuleList'); ?>">角色列表</a></dd>
	        </dl>
	    </li>
	    <li class="layui-nav-item">
	        <a href="javascript:;"><i class="fa fa-database"> 数据库管理</i></a>
	        <dl class="layui-nav-child">
	            <dd><a href="javascript:;" class="site-url" data-title="表操作" data-id="7" data-url="">表操作</a></dd>
	            <dd><a href="javascript:;" class="site-url" data-title="表关联" data-id="8" data-url="">表关联</a></dd>
	        </dl>
	    </li>
	    <li class="layui-nav-item"><a href="javascript:;" class="site-url" data-id="9" data-title="文件管理" data-url="<?php echo url('index/Filemanager/index'); ?>"><i class="fa fa-folder"> 文件管理</i></a></li>
	    <li class="layui-nav-item">
	        <a href="javascript:;"><i class="fa fa-wrench"> 设置</i></a>
	        <dl class="layui-nav-child">
	            <dd><a href="javascript:;" class="site-url" data-title="系统设置" data-id="10" data-url="">系统设置</a></dd>
	            <dd><a href="javascript:;" class="site-url" data-title="网站设置" data-id="11" data-url="">网站设置</a></dd>
	            <dd><a href="javascript:;" class="site-url" data-title="修改密码" data-id="12" data-url="">修改密码</a></dd>
	        </dl>
	    </li>
	</ul>
	<div class="layui-tab layui-tab-brief" lay-filter="contentnav" lay-allowClose="true" style="border-top:1px solid #ccc;margin-left:200px;margin-top:0;">
	    <ul class="layui-tab-title">
	        <li class="layui-this">首页</li>
	    </ul>
	    <ul class="layui-bg-green rightmenu" style="display: none;position: absolute;">
	        <li data-type="closethis">关闭当前</li>
	        <li data-type="closeall">关闭所有</li>
	    </ul>
	    <div class="layui-tab-content" style="padding:0;">
	        <div class="layui-tab-item layui-show">首页内容</div>
	    </div>
	</div>
	
	
	<script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="/static/layui/layui.all.js"></script>
	<script type="text/javascript">
		layui.use('element', function(){
	        var element = layui.element;
	        var active={
	        	//新增一个Tab项 传入三个参数，分别对应其标题，tab页面的地址，还有一个规定的id，是标签中data-id的属性值
                //关于tabAdd的方法所传入的参数可看layui的开发文档中基础方法部分
	            tabAdd:function(url,id,name){
	                element.tabAdd('contentnav',{
	                    title:name,
	                    content:'<iframe id="iframe'+id+'" data-frameid="'+id+'" scrolling="auto" frameborder="0" src="'+url+'" style="width:100%;"></iframe>',
	                    id:id //规定好的id
	                });
	                rightMenu();//给tab绑定右击事件
	                iframeWH(); //计算ifram层的大小
	            },
	            tabChange:function(id){
	            	//切换到指定Tab项
	                element.tabChange('contentnav',id);  //根据传入的id传入到指定的tab项
	            },
	            tabDelete:function(id){
	                element.tabDelete('contentnav',id); //删除
	            },
	            tabDeleteAll:function(ids){ //删除所有
	                $.each(ids,function(index,item){ 
	                    element.tabDelete('contentnav',item);
	                });
	            }
	        };
	        var flag = true;
	        $("#flexibleBtn").on('click',function(){
	        	w = $(document.body).width();
				//这里定义一个全局变量来方便判断动画收缩的效果,也就是放在最外面
				if (flag == true) {
					$('.layui-nav-side').width(60);
		            //将footer和body的宽度修改
					flag = false;
				} else {
					$('.layui-nav-side').width(200); //设置宽度
					flag = true;
				}		
			});
			//当点击有site-url属性的标签时，即左侧菜单栏中内容 ，触发点击事件
	        $(".site-url").on('click',function(){
	            var nav=$(this);
	            var length = $("ul.layui-tab-title li").length;
	            if(length<=0){
	            	// 如果比零小，则直接打开新的tab项
	                active.tabAdd(nav.attr("data-url"),nav.attr("data-id"),nav.attr("data-title"));
	            }else{
	            	// 否则判断该tab项是否以及存在
	                var isData=false; //初始化一个标志，为false说明未打开该tab项 为true则说明已有
	                $.each($("ul.layui-tab-title li"),function(){
	                	// 如果点击左侧菜单栏所传入的id 在右侧tab项中的lay-id属性可以找到，则说明该tab项已经打开
	                    if($(this).attr("lay-id")==nav.attr("data-id")){
	                        isData=true;
	                    }
	                });
	                if(isData==false){
	                	// 标志为false 新增一个tab项
	                    active.tabAdd(nav.attr("data-url"),nav.attr("data-id"),nav.attr("data-title"));
	                }
	                // 最后不管是否新增tab，最后都转到要打开的选项页面上
	                active.tabChange(nav.attr("data-id"));
	            }
	        });
	        function rightMenu(){
	            // 右击弹出
	            $(".layui-tab-title li").on('contextmenu',function(e){
	                var menu=$(".rightmenu");
	                menu.find("li").attr('data-id',$(this).attr("lay-id"));
	                l = e.clientX;
	                t = e.clientY-20;
	                menu.css({ left:l, top:t}).show();
	                return false;
	            });
	            // 左键点击隐藏
	            $("body,.layui-tab-title li").click(function(){
	                $(".rightmenu").hide();
	            });
	        }
	        $(".rightmenu li").click(function(){
	            if($(this).attr("data-type")=="closethis"){
	                active.tabDelete($(this).attr("data-id"));
	            }else if($(this).attr("data-type")=="closeall"){
	                var tabtitle = $(".layui-tab-title li");
	                var ids = new Array();
	                tabtitle.each(function(i){
	                    ids.push($(this).attr("lay-id"));
	                });
	                // 如果关闭所有 ，即将所有的lay-id放进数组，执行tabDeleteAll
	                active.tabDeleteAll(ids);
	            }
	            $('.rightmenu').hide(); // 最后再隐藏右键菜单
	        });
	        function iframeWH(){
	            var H = $(window).height()-140;
	            $("iframe").css("height",H+"px");
	        }
	        $(window).resize(function(){
	            iframeWH();
	        });
	        $("#refreshBtn").click(function(){
	        	var id  = $('.layui-this').find('a').attr("data-id"); 
	        	var src = $('.layui-this').find('a').attr("data-url"); 
	        	$("#iframe"+id).attr('src', src);
	        })
    	}); 
	</script>
	
	</body>
</html>