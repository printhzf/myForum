<?php

return [
    'auth' =>[
	    'AUTH_ON'           => true, // 认证开关
	    'AUTH_TYPE'         => 1, // 认证方式，1为实时认证；2为登录认证。
	    'AUTH_USER'         => 'manager' // 用户信息表
    ],
];