<?php
namespace app\common\controller;

use auth\Auth;
use think\Controller;
use think\Facade\Session;
use think\facade\Request;

class Base extends Controller 
{

	/**
	 * 初始化方法
	 * 1.在所有方法之前调用
	 * 2.常用来创建常量,公共方法等
	 */
	protected function initialize(){
		// $this->checkAuth();
	}

	//  权限校验
	protected function checkAuth() {
		$module = Request::module();
        $controller = Request::controller();
        $action = Request::action();
        $rule = strtolower($module.'/'.$controller.'/'.$action);
        $auth = new Auth();
        $no_check = [
        	'index/index/index',
        ];
        if (!in_array($rule, $no_check)) {
        	if (!$auth->check($rule, session('uid'))) {
           		$this->error('没有访问权限','/index/index/index');
        	}
        }
	}

	// 是否登录
	protected function isLogin()
	{
		if(!Session::has('userId')){
			return $this->error('您还没有登录！','index/usermanager/viewLogin');
		}
	}

	// 是否重复登录
	protected function isRelogin()
	{
		if(Session::has('userId')){
			return $this->error('您已经登录！','index/index/index');
		}
	}
}