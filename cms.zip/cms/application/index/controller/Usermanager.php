<?php
namespace app\index\controller;

use app\common\model\Manager as ManagerModel; //导入User模型并取别名
use app\common\model\User as UserModel; //导入User模型并取别名
use app\common\validate\User as UserValidate; //导入User验证器并取别名
use app\common\controller\Base;

use think\captcha\Captcha;
use think\facade\Session;
use think\facade\Request;
use think\facade\File;

/**
 * 用户管理：
 * 1.用户列表
 * 2.用户信息CURD
 */
class Usermanager extends Base
{

	// 登录页
	public function viewLogin(){
        $this->isRelogin();
		return $this->fetch();
	}

	// 生成验证码
    public function verify(){
    	$config = [
             // 验证码字体大小
            'fontSize' => 30,
            // 验证码位数
            'length'   => 4,
            // 关闭验证码杂点
            'useNoise' => true,
            // 验证码图片高度
            'imageH'   => 50,
            // 验证码图片宽度
            'imageW'   => 300,
            // 验证码过期时间（s）
            'expire'   => 1800,
        ];
        $captcha = new Captcha($config);
        return $captcha->entry();
    }

	// 验证码校验
	public function check(){
        $captcha = Request::param('verify');
        if(!captcha_check($captcha)){
            //验证码错误
            return false;
        }else{
             //验证码正确
        	return true;
        }
    }

    //验证用户登录
	public function checkLogin(){
		if(Request::isAjax()) {
            if($this->check()) {
                $res = [];
                $data = Request::param();
                $validate = new UserValidate;
                if (!$validate->scene('login')->check($data)) {
                    $res = ['code'=>0, 'msg'=>$validate->getError()];
                } else {
                    $map['username'] = $data['username'];
                    $map['password'] = md5($data['password']);
                    $obj = UserModel::where($map)->field('id,username,status,headimg')->find();
                    if (!empty($obj)) {
                        $user = $obj->toArray();
                        if ($user['status'] != '启用'){
                            $res = ['code'=>0,'msg'=>'当前用户已禁用！'];
                        } else {
                            Session::set('userId', $user['id']);
                            Session::set('userName', $user['username']);
                            Session::set('userImg', $user['headimg']);
                            UserModel::where($map)->update(
                                [
                                    'last_login_time' => time(),
                                    'last_login_ip'   => ip2long($_SERVER["REMOTE_ADDR"]),
                                ]
                            );
                            $res = ['code'=>200,'msg'=>'登录成功！'];
                        }
                    } else {
                        $res = ['code'=>0, 'msg'=>'用户名或密码错误！'];
                    }
                }
            } else {
                $res = ['code'=>0, 'msg'=>'验证码错误！'];
            }
            return json($res);
        }
	}

    // 退出登录
    public function logout(){
        //1.清除全部session
        Session::clear();
        //2.退出登录并跳转到登录页面
        $this->redirect('index/index/index');
    }

    // 注册页
    public function viewRegister(){

    	return $this->fetch();
    }

    // 添加用户
    public function create(){

        if(Request::isAjax()){
            $data = Request::param();
            $validate = new UserValidate();
            if (!$validate->scene('register')->check($data)) {
                Session::set('register_email', $data['email']);
                Session::set('register_name', $data['username']);
                Session::set('register_pass', $data['password']);
                return json(array('code' => 0, 'msg' =>$validate->getError()));
            } else {
                $user  = new UserModel();
                $data['userip'] = $_SERVER["REMOTE_ADDR"];
                $user->data($data, true); //批量修改
                $state = $user->allowField(['username','password','email','userip'])->isUpdate(false)->save();
                if ($state == 1){
                    return json(array('code' => 200, 'msg' => '注册成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '注册失败'));
                }
            }
        }
    }

    // 用户编辑
    public function editpage(){
        return $this->fetch();
    }

    // 展示用户列表（能执行到这里,肯定是超级管理员is_admin=1）
    public function viewUserList() {
        return $this->fetch();
    }

	// 获取网站用户列表数据
	public function getUserList() {
        $data = UserModel::all();
        $res = [
            'code' => 0,
            'msg'  => '',
            'count'=> count($data),
            'data' => $data
        ];
        // clearstatcache();// 清除缓存
        return json($res);

	}

    // 展示管理员列表（能执行到这里,肯定是超级管理员is_admin=1）
    public function viewManagerList() {

        return $this->fetch();
    }

    // 获取管理员列表数据
    public function getManagerList() {

    }

	// 渲染编辑用户界面
	public function viewUpdate() {

	}

	public function update() {

	}

	public function delete() {
		
	}


}