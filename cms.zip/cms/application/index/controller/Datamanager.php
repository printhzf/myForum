<?php
namespace app\index\controller;

use app\common\controller\Base;
use think\facade\Request;
use think\facade\File;

/**
 * 数据管理：
 * 1.查询脏数据
 * 1.数据清洗
 */
class Datamanager extends Base
{

	public function index() {
		
	}

	// 查看磁盘大小
	public function getSize() {
// 	SELECT CONCAT(table_schema,'.',table_name) AS 'aaa',   
	
//     table_rows AS 'Number of Rows',   

//     CONCAT(ROUND(data_length/(1024*1024*1024),6),' G') AS 'Data Size',   

//     CONCAT(ROUND(index_length/(1024*1024*1024),6),' G') AS 'Index Size' ,   

//     CONCAT(ROUND((data_length+index_length)/(1024*1024*1024),6),' G') AS'Total'  

// FROM information_schema.TABLES   

// WHERE table_schema LIKE 'olderdb';
	}
}