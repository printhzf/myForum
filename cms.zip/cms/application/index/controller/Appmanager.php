<?php
namespace app\index\controller;

use app\common\controller\Base;

use think\facade\Session;
use think\facade\Request;
use think\facade\File;
use think\Db;

/**
 * 应用管理：
 */
class Appmanager extends Base
{
	// 文章列表
	public function viewTopicList() {

	}

	// 分类列表
	public function viewCategroyList() {

	}

	// 评论列表
	public function viewCommentList() {

	}

	// 回复列表
	public function viewRelyList() {

	}


}