<?php
namespace app\index\controller;

use app\common\controller\Base;

/**
 * 1.内容管理
 * 2.文件管理
 * 3.数据管理
 * 4.用户管理
 * 5.权限管理
 */
class Index extends Base
{

	public function index() {

		return $this->fetch();
	}

}	 
