<?php
namespace app\index\controller;

use app\common\controller\Base;
use think\facade\Request;
use think\facade\File;

/**
 * 文件管理：
 * 1.文件创建
 * 2.判断文件权限
 * 3.文件大小、创建时间、修改时间、访问时间
 * 4.文件内容查看、修改
 * 5.文件删除、重命名、复制、剪切
 * 6.文件上传、下载
 */
class Filemanager extends Base
{

	// 图片后缀
	public $imageExt = ['gif','jpg','png','jpeg'];


	/**
	 * 文件管理页
	 */
	public function index() {
		$dirname = Request::param('path') ? Request::param('path') : '../public/uploads';
		if ($dirname != '../public/uploads') {
			$backDir = dirname($dirname);
		} else {
			$backDir = '../public/uploads';
		}
		$this->assign('backDir',$backDir);
		$this->assign('dirname',$dirname);
		return $this->fetch('viewFileManager');
	}

	/**
	 * 获取指定路径下的所有文件和文件夹
	 * @param $path string 路径
	 * @return $arr array 指定目录下的所有文件与文件夹
	 */
	public function readDir($path){
	    $path .= substr($path, -1) == '/' ? '' : '/';
	    $arr = [];
	    foreach (glob($path.'*') as $v) {
	        if(is_dir($v)){
	            $arr['dir'][] = $v;
	        } 
	        if (is_file($v)) {
				$arr['file'][] = $v;
			}
	    }
	    return $arr;
	}

	/**
	 * 获取文件夹大小
	 * @param $path string 路径
	 * @return $GLOBALS['count'] 文件夹大小
	 */
	public function getDirSzie($path) {
		$GLOBALS['count'] = 0;
		$path .= substr($path, -1) == '/' ? '' : '/';
	    foreach (glob($path.'*') as $v) {
	    	if (is_file($v)) {
				$GLOBALS['count'] += filesize($v);
			}
	        if(is_dir($v)){
	            $this->getDirSzie($v);
	        } 
	    }
	    return $GLOBALS['count'];
	}

	/**
	 * 获取文件夹大小
	 * @param $path string 路径
	 * @return $res json 文件基本信息
	 */
	public function getTableData() {
		// 文件大小
		// 创建、修改、访问时间
		// 文件是否可读、可写、可操作
		$path = Request::param('path');
		$arr  = $this->readDir($path);
		$count= 0;
		$data = [];
		if (!empty($arr['dir'])) {	
			foreach ($arr['dir'] as $k => $v) {
				$size = $this->getDirSzie($v);
				$data[$k] = [
					'id' => $k+1,
					'filename' => basename($v),
					'filetype' => filetype($v),
					'size' => $this->transByte($size),
					'is_readable'  => is_readable($v) ? 'yes' : 'no',
					'is_writeable' => is_writeable($v) ? 'yes' : 'no',
					'is_executable'=> is_executable($v) ? 'yes' : 'no',
					'gmt_create'   => date('Y-m-d H:i:s',filectime($v)),
					'gmt_modified' => date('Y-m-d H:i:s',filemtime($v)),
					'gmt_visited'  => date('Y-m-d H:i:s',fileatime($v)),
				];
			}
			$count = count($data);
		} 
		if (!empty($arr['file'])) {	
			foreach ($arr['file'] as $k => $v) {
				$data[$count+$k] = [
					'id' => $count+$k+1,
					'filename' => basename($v),
					'filetype' => filetype($v),
					'size' => $this->transByte(filesize($v)),
					'is_readable'  => is_readable($v) ? 'yes' : 'no',
					'is_writeable' => is_writeable($v) ? 'yes' : 'no',
					'is_executable'=> is_executable($v) ? 'yes' : 'no',
					'gmt_create'   => date('Y-m-d H:i:s',filectime($v)),
					'gmt_modified' => date('Y-m-d H:i:s',filemtime($v)),
					'gmt_visited'  => date('Y-m-d H:i:s',fileatime($v)),
				];
			}
		}
		$res = [
			'code' => 0,
			'msg'  => '',
			'count'=> count($data),
			'data' => $data
		];
		// clearstatcache();// 清除缓存
		return json($res);
	}

	/**
	 * 获取文件夹大小
	 * @param $path string 路径
	 * @return $res json 文件基本信息
	 */
	public function getFileContent() {
		$path = Request::param('path');
		$type = filetype($path);
		$content = file_get_contents($path);
		if (mb_strlen($content) > 0) {
			$content = iconv("gb2312", "utf-8", $content);  
			$newContent = highlight_string($content, true);
			return json(array('code'=>200,'msg'=>$newContent));

		} else {
			return json(array('code'=>0,'msg'=>'文件内容为空'));
		}
	}

	/**
	 * 文字格式转换
	 * @param $data string 文字
	 * @return $data utf8格式
	 */
	public static function convert_utf8($data) {
		if( !empty($data) ){
			$fileType = mb_detect_encoding($data , mb_list_encodings(), true);
			if( strtolower($fileType) != 'utf-8'){
				$data = mb_convert_encoding($data ,'utf-8' , $fileType);  
			}
		}
		return $data;
	}

	/**
	 * 字节单位转换
	 * @param $size string 字节大小
	 * @return $size
	 */
	public static function transByte($size) {
		$arr = ['Byte', 'KB', 'MB', 'GB', 'TB', 'EB'];
		$i = 0;
		while ($size>=1024) {
			$size /= 1024;
			$i++; 
		}
		return round($size,2).$arr[$i];
	}

	/**
	 * 文件名字校验
	 * @param $path string 字节大小
	 * @return boolaan 
	 */
	public function cheackFilename($path) {
		// 验证文件名是否包含,;；，《》*?/|
		$pattern = '/[、,;；，《》\*\?\/\|]+/';
		if (preg_match($pattern, basename($path))) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 创建文件
	 * @param $path 路径
	 * @return $size
	 */
	public function createFile() {
		$path = Request::param('path');
		if (!$this->cheackFilename($path)) {
			return json(array('code'=>0,'msg'=>'文件名含有非法字符'));
		} else {
			// 检测当前目录是否包含同名文件
			if (!file_exists($path)) {
				if (touch($path)){
					return json(array('code'=>200,'msg'=>'创建成功'));
				}
			} else {
				return json(array('code'=>0,'msg'=>'当前目录已存在同名文件，请重命名后创建'));
			}
		}
	}

	/**
	 * 文件复制
	 * @param $size string 字节大小
	 * @return $size
	 */
	public function copyFile() {
		$filename= Request::param('filename');
		$dirname = Request::param('dirname');
		if (!file_exists($dirname)) { 
			if (!file_exists($dirname.'/'.$filename)) {
				if (copy($filename, $dirname)) {
					return json(array('code'=>200,'msg'=>'复制成功'));
				} else {
					return json(array('code'=>0,'msg'=>'复制失败'));
				}
			} else {
				return json(array('code'=>0,'msg'=>'存在同名文件'));
			}
		} else {
			return json(array('code'=>0,'msg'=>'目标目录不存在'));
		}
	}

	/**
	 * 文件剪切
	 * @param $size string 字节大小
	 * @return $size
	 */
	public function cutFile() {
		$filename= Request::param('filename');
		$dirname = Request::param('dirname');
		if (!file_exists($dirname)) { 
			if (!file_exists($dirname.'/'.$filename)) {
				if (rename($filename, $dirname)) {
					return json(array('code'=>200,'msg'=>'剪切成功'));
				} else {
					return json(array('code'=>0,'msg'=>'剪切失败'));
				}
			} else {
				return json(array('code'=>0,'msg'=>'存在同名文件'));
			}
		} else {
			return json(array('code'=>0,'msg'=>'目标目录不存在'));
		}
	}

	/**
	 * 文件内容更新
	 * @param $path string 字节大小
	 * @return $html
	 */
	public function viweUpdateFile() {
		$path = Request::param('path');
		$ext  = substr($path, strrpos($path, ".") + 1);
		if (in_array($ext, $this->imageExt)) {

		} else {

			$content = file_get_contents($path);
			$newContent = '';
			if (mb_strlen($content) > 0) {
				$content = iconv("gb2312", "utf-8", $content);  
				$newContent = highlight_string($content, true);
			} 
			$html = <<<EOF
	<div style="text-align:center;padding:10px;">
		<form class="layui-form layui-form-pane">
		<input name="path" type="hidden" value="{$path}">
		<div class="layui-form-item layui-form-text">
			<div class="layui-input-block">
				<textarea name="newFileContent" placeholder="请输入内容" class="layui-textarea" style="height:178px">{$newContent}</textarea>
			</div>
		</div>
		</form>
		<button class="button button-3d button-primary button-rounded" onclick="updateFile()">保存</button>
	</div>
EOF;
			return $html;
		}
	}

	/**
	 * 文件重命名
	 * @param $path string 路径
	 * @param $name string 新文件名
	 * @return $res json 返回信息
	 */
	public function renameFunc() {
		$path = Request::param('path');
		$name = Request::param('name');
		if ($this->cheackFilename($name)) {
			// 检测当前目录是否包含同名文件
			$newPath = dirname($path).'/'.$name;
			if (!file_exists($newPath)) {
				if (rename($path, $newPath)) {
					return json(array('code'=>200,'msg'=>'重命名成功'));
				}
			} else {
				return json(array('code'=>0,'msg'=>'当前目录已存在同名文件，请重命名'));
			}
		} else {
			return json(array('code'=>0,'msg'=>'输入参数含有非法字符'));
		}
	}

	/**
	 * 编辑文件内容
	 * @param $path string 路径
	 * @return $res json 返回信息
	 */
	public function updateFile() {
		$path = Request::param('path');
		$content = Request::param('content');
		if (file_put_contents($path, $content)) {
			return json(array('code'=>200,'msg'=>'文件内容修改成功'));
		} else {
			return json(array('code'=>0,'msg'=>'文件内容修改失败'));
		}
	}

	/**
	 * 删除文件或文件夹
	 * @param $path string 路径
	 * @return $res json 返回信息
	 */
	public function deleteFunc() {
		$path = Request::param('path');
		if (filetype($path) == 'dir') {
			$this->deleteDir($v);
		} else {
			$this->deleteFile($path);
		}
	}

	/**
	 * 删除文件
	 * @param $path string 路径
	 * @return $res json 返回信息
	 */
	public function deleteFile($path) {
		if (file_exists($path)) { 
			if (unlink($path)){
				return json(array('code'=>200,'msg'=>'删除成功'));
			}
		} else {
			return json(array('code'=>0,'msg'=>'此文件已被删除'));
		}
	}

	/**
	 * 删除文件夹
	 * @param $path string 路径
	 * @return $res json 返回信息
	 */
	public function deleteDir($path) {
		$path .= substr($path, -1) == '/' ? '' : '/';
	    foreach (glob($path.'*') as $v) {
	        if(is_dir($v)){
	            $this->deleteDir($v);
	        } 
	        if (is_file($v)) {
				unlink($v);
			}
	    }
	    if (rmdir($path)) {
	    	return json(array('code'=>200,'msg'=>'删除成功'));
	    } else {
	    	return json(array('code'=>0,'msg'=>'此文件夹已被删除'));
	    }
	}

	/**
	 * 下载文件
	 * @param $path string 路径
	 */
	public function downloadFile() {
		$path = Request::param('filename');
		//检查文件是否存在    
		if (!file_exists($path)) {    
			header('HTTP/1.1 404 NOT FOUND');  
		} else {    
			//告诉浏览器这是一个文件流格式的文件    
			Header ("Content-type: application/octet-stream"); 
			// //请求范围的度量单位  
			Header ("Accept-Ranges: bytes");  
			// //Content-Length是指定包含于请求或响应中数据的字节长度    
			Header ("Accept-Length: ".filesize($path));  
			//用来告诉浏览器，文件是可以当做附件被下载，下载后的文件名称为$file_name该变量的值。
			Header("Content-Disposition: attachment; filename=".basename($path));   
			Header("Content-Length:".filesize($path));   
			readfile($path);
		}    

	}

	public function viewUploadFile() {
		return $this->fetch();
	}

	/**
	 * 上传文件
	 */
	public function uploadFile() {

        $file = Request::instance()->file('file');
        if (!empty($file)) {  
	        $info = $file->move('../public/uploads'); 
	        if ($info) {
	            $code = 0;
	            $data['url'] = $info->getSaveName();
	            $message = '文件上传成功！';
	        } else {
	        	$code = 2;
	        	$data = [];
	            $message = '文件上传失败！'.$file->getError();
	        }
        	return self::showMsg($code, $message, $data);
        } 
    }

    public static function showMsg($code = 0, $message, $data = array()) {
        $result = array(
            'code'  => $code,
            'message' => $message,
            'data'    => $data
        );
        return json($result);
    }


	public function getExt($filename) {
		return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
	}

	/**
	 * 遍历获取文件夹
	 */
	public function listDir($path){
	    $path .= substr($path, -1) == '/' ? '' : '/';
	    $arr = [];
	    foreach (glob($path.'*') as $v) {
	        $arr[] = $v; 
	        if(is_dir($v)){
	            $arr['dir'][] = array_merge($arr, $this->listDir($v));
	        } 
	    }
	    return $arr;
	}
}	 
