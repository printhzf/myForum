<?php
namespace app\index\controller;

use auth\Auth;
use app\common\controller\Base;

use think\facade\Session;
use think\facade\Request;
use think\facade\File;
use think\Db;

/**
 * 权限管理：
 */
class Authmanager extends Base
{

	// 用户权限页
	public function viewGroupAcess(){
		// $uid  = Session::get('userId');
		$uid = 1;
        $auth = new Auth();
        $groups = $auth->getGroups($uid);
        print_r($groups);exit;
		return $this->fetch();
	}

    // 角色权限列表页
    public function viewRuleList(){

        return $this->fetch();
    }

    public function getRuleList() {
    	$prefix = config('database.prefix');
    	$roleList = Db::table("{$prefix}auth_group")->select();
    	$ruleList = Db::table("{$prefix}auth_rule")->select();
    	foreach ($roleList as $k => $v) {
    		$rules = explode(',', $v['rules']);
    		foreach ($rules as $k2 => $v2) {
    			$id = $v2 - 1;
    			$title[] = $ruleList[$id]['title'];
    		}
    		$roleList[$k]['rules'] = implode('、', $title);
    		unset($title);
    	}
    	$res = [
            'code' => 0,
            'msg'  => '',
            'count'=> count($roleList),
            'data' => $roleList
        ];
    	return json($res);
    }


}