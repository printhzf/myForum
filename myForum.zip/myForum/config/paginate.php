<?php 
return [

'type' => 'bootstrap',

'var_page' => 'p', 
];