<?php /*a:3:{s:61:"F:\wamp64\www\myForum\application/index/view\index\index.html";i:1542505317;s:63:"F:\wamp64\www\myForum\application/index/view\layout\layout.html";i:1542593457;s:66:"F:\wamp64\www\myForum\application/index/view\index\topicsList.html";i:1542593518;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>
		
			<?php echo htmlentities(app('config')->get('web_title')); ?>-<?php echo htmlentities((isset($title) && ($title !== '')?$title:"首页")); ?>
		
	</title>

	
	
	<!-- 使用load标签加载资源文件 -->
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/layout.css" />
    <script type="text/javascript" src="/static/layui/layui.js"></script>
    <script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
</head>
<body>
	<!-- 导航 -->
	<div class="header">
		<ul class="layui-nav">
			<!-- 默认首页高亮显示-->
			<li class='layui-nav-item <?php if(empty(app('request')->param('cate_id')) || ((app('request')->param('cate_id') instanceof \think\Collection || app('request')->param('cate_id') instanceof \think\Paginator ) && app('request')->param('cate_id')->isEmpty())): ?> layui-this <?php endif; ?>'>
				<a href="<?php echo url('index/index/index'); ?>">首页</a>
			</li>
			<li class="layui-nav-item">
				<a href="javascript:;">文章分类</a>
				<dl class="layui-nav-child"> <!-- 二级菜单 -->
					<?php if(is_array($cateList) || $cateList instanceof \think\Collection || $cateList instanceof \think\Paginator): $i = 0; $__LIST__ = $cateList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
					<dd 
					
			        <?php if($v['id'] == app('request')->param('cate_id')): ?>  
			         class="layui-this"
			        <?php endif; ?>>
		        		<a href="<?php echo url('index/index',['cate_id'=> $v['id']]); ?>"><?php echo htmlentities($v['name']); ?></a>
		        	</dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</dl>
			</li>
			<li class="layui-nav-item" style='float: right;'><a href="<?php echo url('user/register'); ?>">注册</a></li>
			<li class="layui-nav-item" style='float: right;'>
				<?php if(empty(app('session')->get('userId')) || ((app('session')->get('userId') instanceof \think\Collection || app('session')->get('userId') instanceof \think\Paginator ) && app('session')->get('userId')->isEmpty())): ?>
					<a href="<?php echo url('index/user/login'); ?>">登录</a>
				<?php else: ?>
					<a>
						<?php if(app('session')->get('userImg') == '0'): ?>
							<img src="/static/images/user/headimg.jpg" class="layui-nav-img"/>
						<?php else: ?>
							<img src="<?php echo htmlentities(app('session')->get('userImg')); ?>" class="layui-nav-img"/>
						<?php endif; ?>
						<?php echo htmlentities(app('session')->get('userName')); ?>
					</a>
					<!-- 跳转到后台的管理中心 -->
		            <dl class="layui-nav-child">
		            	<dd><a href="<?php echo url('user/editpage'); ?>">管理中心</a></dd>
		            	<dd><a href="<?php echo url('user/logout'); ?>">退出登录</a></dd>
		        	</dl>
				<?php endif; ?>
			</li>

		</ul>
	</div>
	<div class="container">	
		
		<!-- 帖子列表 -->
		<div class="topicsList box">
			<h2>
				<?php echo htmlentities($cateName); ?>
				<button id="addtopicBtn" class="layui-btn layui-btn-primary layui-btn-sm" style="float: right;">
					<a href="<?php echo url('index/index/add'); ?>" target='_blank'>
						<i class="layui-icon layui-icon-edit" style="color: #1E9FFF;"></i>发表帖子
					</a>
				</button>
			</h2>
			<hr/>
			<?php if(is_array($topicsList) || $topicsList instanceof \think\Collection || $topicsList instanceof \think\Paginator): $i = 0; $__LIST__ = $topicsList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
<div class="topicBox">
    <div class="topicBox-header">
        <h3>
            <a href="#" target="_blank"><?php echo htmlentities($list['title']); ?></a>
        </h3>
        <ul>
            <li>
                <i class="layui-icon layui-icon-username"> <?php echo htmlentities($list['username']); ?></i>
            </li>
            <li>
                <i class="layui-icon layui-icon-date"> <?php echo htmlentities($list['create_time']); ?></i>
            </li>
            <li>
                <i class="layui-icon layui-icon-note"></i> <a href="#" target="_blank">标签</a>
            </li>
            <li>
                <i class="layui-icon layui-icon-reply-fill"> 回复量</i>
            </li>
            <li>
                <i class="layui-icon layui-icon-star"> 点击收藏</i>
            </li>
        </ul>
    </div>
    <div class="topicBox-body">
        <!-- 文章封面图片开始 -->
        <div class="titleImgBox">
            <a href="#" target="_blank">
            <?php if(empty($list['title_img']) || (($list['title_img'] instanceof \think\Collection || $list['title_img'] instanceof \think\Paginator ) && $list['title_img']->isEmpty())): ?>
                <img src="/static/images/index/titleimg.png" class='img' />
            <?php else: ?>
                <img src="/upload/<?php echo htmlentities($list['title_img']); ?>" class='img' />
            <?php endif; ?> 
            </a>
        </div>
        <!-- 文章封面图片结束 -->

        <!-- 文章描述开始 -->
        <div class="topicBriefBox">
            <div class="topicBrief">
                <?php echo htmlentities(mb_substr($list['body'],0,150)); ?>...
            </div>
            <!-- 文章描述结束 -->
            <a class="layui-btn layui-btn-sm readall" href="<?php echo url('index/index/details',['topic_id'=> $list['id']]); ?>" target="_blank">
                阅读全文
            </a>
        </div>
    </div>
</div>
<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
		<div class="right">	
			<!-- 搜索栏 -->
			<div class="searchBar box">
			    <div class="layui-inline">
					<div class="layui-input-inline">
						<input id="search" name="keywords" type="text" autocomplete="off" class="layui-input">
					</div>
					<button id="searchBtn" class="layui-btn" lay-submit="">全站搜索</button>
			    </div>
			</div>
			<!-- 最新帖子标题列表 -->
			<div class="hotList box">
				<h2>热门帖子</h2><hr/>
				<?php if(is_array($hotList) || $hotList instanceof \think\Collection || $hotList instanceof \think\Paginator): $i = 0; $__LIST__ = $hotList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$list): $mod = ($i % 2 );++$i;?>
					<a href="<?php echo url('index/index/details',['topic_id'=> $list['id']]); ?>">·<?php echo htmlentities($list['title']); ?></a>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</div>
			<!-- 标签云 -->
			<div class="tagCloud box">
				<h2>标签云</h2><hr/>
				
			</div>
		</div>
		
	</div>
	<div class="footer">

		<div class="footer-content-a">
			<dl>
                <dt><b>权益</b></dt>
                <dd>许可协议：xxx</dd>
                <dd>版权所有：xxx</dd>
                <dd>网站备案：xxx</dd>
                <dd>联系邮箱：1692145479@qq.com</dd>
        	</dl>
		</div>

		<div class="footer-content-b">
			<dl>
                <dt><b>架构</b></dt>
                <dd>项目名称：<a rel="nofollow" href="#" target="_blank">myForum</a></dd>
                <dd>版本分支：v1.0</dd>
                <dd>项目作者：<a href="#">printhzf</a></dd>
            </dl>
		</div>

		<div class="footer-content-c">
			<dl>
                <dt><b>统计</b></dt>
                <dd>文章总数：xx</dd>
                <dd>评论总数：xxx</dd>
                <dd>登录用户：xxx</dd>
            </dl>
		</div>

	</div>
	
	<script type="text/javascript">
		//注意：导航 依赖 element 模块，否则无法进行功能性操作
		layui.use(['element','layer'], function(){
		    var $ = layui.jquery, 
		    	element  = layui.element,
		    	layer    = layui.layer;
		});
		$("#searchBtn").bind('click',function(){
			var keywords = $("#search").val();
			if(keywords != ''){
				$.ajax({
	                url    : 'index',
	                type   : 'post',
	                data   :  {'keywords':keywords},
	                success: function(){}
	            })
			}
		});
	</script>
	
</body>
</html>