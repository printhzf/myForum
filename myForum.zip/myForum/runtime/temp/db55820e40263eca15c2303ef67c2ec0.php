<?php /*a:2:{s:61:"F:\wamp64\www\myForum\application/index/view\index\index.html";i:1542100494;s:63:"F:\wamp64\www\myForum\application/index/view\layout\layout.html";i:1542188759;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
	<title><?php echo htmlentities(app('config')->get('web_title')); ?>-<?php echo htmlentities((isset($title) && ($title !== '')?$title:"首页")); ?></title>
	
	<!-- 使用load标签加载资源文件 -->
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/layout.css" />
    <script type="text/javascript" src="/static/layui/layui.js"></script>

    

</head>
<body>
	<!-- 导航 -->
	<div class="header">
		<ul class="layui-nav" style="padding-left: 8%">
			<!-- 默认首页高亮显示-->
			<li class='layui-nav-item <?php if(empty(app('request')->param('cate_id')) || ((app('request')->param('cate_id') instanceof \think\Collection || app('request')->param('cate_id') instanceof \think\Paginator ) && app('request')->param('cate_id')->isEmpty())): ?> layui-this <?php endif; ?>'>
				<a href="<?php echo url('index/index/index'); ?>">首页</a>
			</li>
			<li class="layui-nav-item">
				<a href="javascript:;">文章分类</a>
				<dl class="layui-nav-child"> <!-- 二级菜单 -->
					<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
					<dd 
					
			        <?php if($v['id'] == app('request')->param('cate_id')): ?>  
			         class="layui-this"
			        <?php endif; ?>>
		        		<a href="<?php echo url('index/index',['cate_id'=> $v['id']]); ?>"><?php echo htmlentities($v['name']); ?></a>
		        	</dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</dl>
			</li>
			<li class="layui-nav-item" style='float: right;'><a href="<?php echo url('user/register'); ?>">注册</a></li>
			<li class="layui-nav-item" style='float: right;'>
				<?php if(empty(app('session')->get('userId')) || ((app('session')->get('userId') instanceof \think\Collection || app('session')->get('userId') instanceof \think\Paginator ) && app('session')->get('userId')->isEmpty())): ?>
					<a href="<?php echo url('index/user/login'); ?>">登录</a>
				<?php else: ?>
					<a>
						<?php if(app('session')->get('userImg') == '0'): ?>
							<img src="<?php echo htmlentities(app('session')->get('userImg')); ?>" class="layui-nav-img"/>
						<?php else: ?>
							<img src="/static/images/user/headimg2.jpg" class="layui-nav-img"/>
						<?php endif; ?>
						<?php echo htmlentities(app('session')->get('username')); ?>
					</a>
					<!-- 跳转到后台的管理中心 -->
		            <dl class="layui-nav-child">
		            	<dd><a href="<?php echo url('user/editpage'); ?>">管理中心</a></dd>
		            	<dd><a href="<?php echo url('user/logout'); ?>">退出登录</a></dd>
		        	</dl>
				<?php endif; ?>
			</li>

		</ul>
	</div>
	<div class="container">	
		
		<!-- 文章列表 -->
		<div class="list box">
			<h2>文章列表</h2><hr/>
		</div>
		<div class="right">	
			<!-- 搜索栏 -->
			<div class="searchBar box">
			    <div class="layui-inline">
					<div class="layui-input-inline">
						<input id="search" name="" type="text" autocomplete="off" class="layui-input">
					</div>
					<button id="searchBtn" class="layui-btn" lay-submit="">全站搜索</button>
			    </div>
			</div>
			<!-- 最新文章标题列表 -->
			<div class="latest box">
				<h2>热门文章</h2><hr/>
			</div>
			<!-- 标签云 -->
			<div class="cloud box">
				<h2>标签云</h2><hr/>
			</div>
		</div>
		
	</div>
	<div class="footer">
		<h2>底部</h2>
	</div>
	
	<script type="text/javascript">
		//注意：导航 依赖 element 模块，否则无法进行功能性操作
		layui.use('element', function(){
		  var element = layui.element;
		});
	</script>
</body>
</html>