<?php /*a:1:{s:60:"F:\wamp64\www\myForum\application/admin/view\topics\add.html";i:1542337265;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo htmlentities(app('config')->get('web_title')); ?>-<?php echo htmlentities((isset($title) && ($title !== '')?$title:"帖子发布页")); ?></title>
	<!-- 使用load标签加载资源文件 -->
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <script type="text/javascript" src="/static/layui/layui.js"></script>

</head>
<body>
</body>
</html>