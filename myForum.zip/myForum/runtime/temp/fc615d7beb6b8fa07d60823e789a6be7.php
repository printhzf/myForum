<?php /*a:1:{s:60:"F:\wamp64\www\myForum\application/index/view\user\login.html";i:1542177033;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
	    <meta name="renderer" content="webkit">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	    <title><?php echo htmlentities(app('config')->get('web_title')); ?>-登录页</title>
	   
		<link rel="stylesheet" href="/static/frame/layui/css/layui.css">
	    <link rel="stylesheet" href="/static/frame/static/css/style.css">
	    <link rel="icon" href="/static/frame/static/image/code.png">
	</head>
	<body>
		<div class="login-main">
			<header class="layui-elip">登录</header>
			<!-- action="<?php echo url('index/user/check'); ?>" -->
		    <form id="form_login" class="layui-form">
		        <!-- CSRF Token -->
		        <?php echo token(); ?>
		        <div class="layui-input-inline">
		            <input type="text" name="username" lay-verify="username1" placeholder="用户名" autocomplete="off" class="layui-input" value="<?php echo htmlentities((isset($usernmae) && ($usernmae !== '')?$usernmae:'')); ?>">
		        </div>
		        <div class="layui-input-inline">
		            <input type="password" name="password" lay-verify="password1" placeholder="密码" autocomplete="off" class="layui-input" value="<?php echo htmlentities((isset($password) && ($password !== '')?$password:'')); ?>">
		        </div>
		        <div class="layui-input-inline">
	                <div class="layui-input-inline">
	                    <input type="text" name="verify" autocomplete="off" placeholder="请输入验证码" autocomplete="off" class="layui-input">
	                    <!-- 测试验证码 -->
					    <div id="captcha" style="margin-top: 20px">
					        <img id="verify_img" src="<?php echo captcha_src(); ?>" alt="验证码" onclick="refreshVerify()">
					    </div>
	                </div>
	            </div>
	            
		        <div class="layui-input-inline login-btn">
		            <button type="submit" class="layui-btn"  lay-filter="add" lay-submit>登录</button>
		        </div>
		        <hr/>
		        <!--<div class="layui-input-inline">
		            <button type="button" class="layui-btn layui-btn-primary">QQ登录</button>
		        </div>
		        <div class="layui-input-inline">
		            <button type="button" class="layui-btn layui-btn-normal">微信登录</button>
		        </div>-->
		        <p><a href="<?php echo url('index/user/register'); ?>" class="fl">立即注册</a><a href="javascript:;" class="fr">忘记密码？</a></p>
		    </form>
		</div>
		<script src="/static/js/jquery-3.3.1.min.js"></script>
		<script src="/static/frame/layui/layui.js"></script>
		<script type="text/javascript">
			layui.use(['form','jquery','layer'], function () {
		        var form   = layui.form;
		        var $      = layui.jquery;
		        var layer  = layui.layer;
		        form.verify({
		            //支持函数式/数组的形式
		            username: function(value, item){ //value：表单的值、item：表单的DOM对象
		                if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
		                    return '用户名不能有特殊字符';
		                }
		                if(/(^\_)|(\__)|(\_+$)/.test(value)){
		                    return '用户名首尾不能出现下划线\'_\'';
		                }
		                if( /^[\S]{4,16}$/.test(value)){
		                    return '密码必须4到16位，且不能出现空格';
		                }
		                if(/^\d+\d+\d$/.test(value)){
		                    return '用户名不能全为数字';
		                }
		            }
		            //数组的两个值分别代表：[正则匹配、匹配不符时的提示文字]
		            ,password: [
		                /^[\S]{6,16}$/
		                ,'密码必须6到16位，且不能出现空格'
		            ] 
		        });      
		        //添加表单监听事件,提交登录信息
		        form.on('submit(add)', function() {
		        	var data = $("#form_login").serialize();
		            $.ajax({
		                url    : 'checkLogin',
		                type   : 'post',
		                data   :  data,
		                success: function(res){
		                    if (res.code == 200) {
		                        window.location.href = "../index/index";
		                    }else {
		                        layer.msg(res.msg);
		                        refreshVerify();
		                    }
		                }
		            })
		            //防止页面跳转
		            return false;
		        });
		 
		    });	

			function refreshVerify() {
	            var ts = Date.parse(new Date())/1000;
	            var img = document.getElementById('verify_img');
	            img.src = "/captcha?id="+ts;
	        }
		</script>
	</body>
</html>