<?php /*a:1:{s:63:"F:\wamp64\www\myForum\application/index/view\user\editpage.html";i:1542070443;}*/ ?>
<html>
<head>
	<title><?php echo htmlentities(app('config')->get('web_title')); ?>-个人资料编辑</title>
    <link rel="stylesheet" type="text/css" href="/../static/layui/css/layui.css">
    <script type="text/javascript" src="/../static/layui/layui.js "></script>
    <style type="text/css">
        .bigBox{
            width: 600px;
            border: 1px dashed #ccc;
            padding: 20px;
            margin: 0 auto;
        }
        .container{
            display: flex;
            justify-content: space-between;
        }
        .left{
            width: 350px;margin-top: 10px;
        }
        .right{
            width: 200px;
        }
        .uploadImg{
            width : 100%;
            height: 190px;
            cursor: pointer;
        }
        #headimg{
            width : 200px;
            height: 100%;
        }
        #preview{
            width : 100%;
            height: 100%;
            background-size: 200px 200px;
            background-image:url("__CSS__/img/user/plus.png");
            background-repeat:no-repeat;
            background-position:center;
            cursor: pointer;
            border-image: none;
        }
    </style>
</head>
    <body>
    <div class="bigBox">
        <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
            <legend>个人资料编辑</legend>
        </fieldset>
        <div class="container">
            <div class="left">
                <form id='userinfo_edit' class="layui-form layui-form-pane" >
                    <div class="layui-form-item">
                        <label class="layui-form-label">用户名</label>
                        <div class="layui-input-block">
                            <input type="text" name="username" autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <label class="layui-form-label">邮箱</label>
                        <div class="layui-input-block">
                            <input type="text" name="email" autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    <div class="layui-form-item layui-form-text">
                        <label class="layui-form-label">个人简介</label>
                        <div class="layui-input-block">
                            <textarea name="resume" class="layui-textarea"></textarea>
                        </div>
                    </div>
                    <div class="layui-form-item">
                        <div class="layui-input-inline" style="width: 80px">
                            <button id="add" class="layui-btn" type="submit" lay-filter="add" lay-submit>提交</button>
                        </div>
                    </div>
                </form>
            </div>
            <!-- 上传图片 -->           
            <fieldset class="layui-elem-field" style="height: 250px">
                <legend>点击上传头像</legend>
                <div class="layui-field-box">
                    <div class="right">
                        <div class="uploadImg">
                            <div id="headimg">
                                <img id="preview"/>
                                <div id="errorText"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </fieldset>

            
        </div>
    </div>
    </body>
    <script src="/static/layui/layui.js"></script>
    <script src="/static/js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript">
        //一般直接写在一个js文件中
        layui.use(['layer', 'table', 'form' ,'upload'], function(){
            var layer   = layui.layer
                ,table  = layui.table
                ,form   = layui.form
                ,upload = layui.upload;
            var uploadHeadImg = upload.render({
                elem: '#headimg'
                ,url : 'upload'
                ,method: 'post'
                ,auto: false
                ,bindAction: '#add'
                ,accept: "images"        //指定允许上传时校验的文件类型
                ,acceptMime:'image/*'    //只显示图片文件
                ,exts:"jpg|png|gif|jpeg" //允许后缀
                ,choose: function(obj){
                    obj.preview(function(index, file, result){
                        $('#preview').attr('src',result);
                    });
                }
                ,before: function(obj){
                    layer.msg('图片上传中...', {
                        icon: 16,
                        shade: 0.01,
                        time: 300
                    });
                }
                ,done : function(res){
                    console.log(res);
                    layer.closeAll('loading'); //关闭loading 
                }
                ,error:function(index,upload){
                    layer.closeAll('loading'); //关闭loading
                    // layer.msg('图片上传失败！');
                }
                ,accept: 'images'//允许上传类型：file(所有文件)、video、images、audio
                ,exts: 'jpg|png' //允许上传后缀名，结合accept使用，若accept为file类型时，exts:'zip|rar|7z'即代表只允许上传压缩文件。若有accept未设定，则限制图片文件格式。
                ,size: '2048'//允许上传大小，单位KB。0（即不受限制）
            }); 
            
            //添加表单监听事件,提交登录信息
            form.on('submit(add)', function() {
                var data = $("#userinfo_edit").serialize();
                $.ajax({
                    url    : 'upload',
                    type   : 'post',
                    data   :  data,
                    success: function(res){
                        console.log(res);return;
                        if (res.code == 200) {
                            layer.msg(res.msg);
                            ///location.href = "login.html";
                        }else {
                            layer.msg(res.msg);
                            refreshVerify();
                            // window.location.reload();
                        }
                    }
                })
                //防止页面跳转
                return false;
            });

        });
  </script> 
</body>
</html>