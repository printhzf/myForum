<?php /*a:2:{s:59:"F:\wamp64\www\myForum\application/index/view\index\add.html";i:1542590963;s:63:"F:\wamp64\www\myForum\application/index/view\layout\layout.html";i:1542590955;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>
		
	
			<?php echo htmlentities(app('config')->get('web_title')); ?>-<?php echo htmlentities((isset($title) && ($title !== '')?$title:"首页")); ?>
		

	</title>

	
<style>
	.addtopicsBox{
		width: 80%;
		height: 600px;
		padding: 50px;
		margin: 0 auto;
		/*border: 1px dashed #ccc;*/
	}
</style>

	
	<!-- 使用load标签加载资源文件 -->
    <link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css" />
    <link rel="stylesheet" type="text/css" href="/static/css/layout.css" />
    <script type="text/javascript" src="/static/layui/layui.js"></script>
    <script type="text/javascript" src="/static/js/jquery-3.3.1.min.js"></script>
</head>
<body>
	<!-- 导航 -->
	<div class="header">
		<ul class="layui-nav">
			<!-- 默认首页高亮显示-->
			<li class='layui-nav-item <?php if(empty(app('request')->param('cate_id')) || ((app('request')->param('cate_id') instanceof \think\Collection || app('request')->param('cate_id') instanceof \think\Paginator ) && app('request')->param('cate_id')->isEmpty())): ?> layui-this <?php endif; ?>'>
				<a href="<?php echo url('index/index/index'); ?>">首页</a>
			</li>
			<li class="layui-nav-item">
				<a href="javascript:;">文章分类</a>
				<dl class="layui-nav-child"> <!-- 二级菜单 -->
					<?php if(is_array($cateList) || $cateList instanceof \think\Collection || $cateList instanceof \think\Paginator): $i = 0; $__LIST__ = $cateList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
					<dd 
					
			        <?php if($v['id'] == app('request')->param('cate_id')): ?>  
			         class="layui-this"
			        <?php endif; ?>>
		        		<a href="<?php echo url('index/index',['cate_id'=> $v['id']]); ?>"><?php echo htmlentities($v['name']); ?></a>
		        	</dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</dl>
			</li>
			<li class="layui-nav-item" style='float: right;'><a href="<?php echo url('user/register'); ?>">注册</a></li>
			<li class="layui-nav-item" style='float: right;'>
				<?php if(empty(app('session')->get('userId')) || ((app('session')->get('userId') instanceof \think\Collection || app('session')->get('userId') instanceof \think\Paginator ) && app('session')->get('userId')->isEmpty())): ?>
					<a href="<?php echo url('index/user/login'); ?>">登录</a>
				<?php else: ?>
					<a>
						<?php if(app('session')->get('userImg') == '0'): ?>
							<img src="/static/images/user/headimg.jpg" class="layui-nav-img"/>
						<?php else: ?>
							<img src="<?php echo htmlentities(app('session')->get('userImg')); ?>" class="layui-nav-img"/>
						<?php endif; ?>
						<?php echo htmlentities(app('session')->get('userName')); ?>
					</a>
					<!-- 跳转到后台的管理中心 -->
		            <dl class="layui-nav-child">
		            	<dd><a href="<?php echo url('user/editpage'); ?>">管理中心</a></dd>
		            	<dd><a href="<?php echo url('user/logout'); ?>">退出登录</a></dd>
		        	</dl>
				<?php endif; ?>
			</li>

		</ul>
	</div>
	<div class="container">	
		
<!-- 表单选项 -->
<div class="addtopicsBox">
	<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
	  <legend style="font-size:30px;">文章发布</legend>
	</fieldset>
    <form id="form_topics" class="layui-form layui-form-pane">
        <!-- CSRF Token -->
        <?php echo token(); ?>
        <input type="hidden" name="user_id" value="<?php echo htmlentities((app('session')->get('userId') ?: 1)); ?>">
        <div class="layui-form-item">
			<label class="layui-form-label">文章标题</label>
			<div class="layui-input-block">
				<input type="text" name="title" autocomplete="off" placeholder="请输入标题" class="layui-input" lay-filter="title">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">文章分类</label>
		    <div class="layui-input-block">
				<select name="category_id" lay-filter="category">
					<?php if(is_array($cateList) || $cateList instanceof \think\Collection || $cateList instanceof \think\Paginator): $i = 0; $__LIST__ = $cateList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<option value="<?php echo htmlentities($v['id']); ?>"><?php echo htmlentities($v['name']); ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
		    </div>
		</div>
		<div class="layui-form-item layui-form-text">
			<label class="layui-form-label">文章内容</label>
			<div class="layui-input-block">
				<textarea name='body' placeholder="请输入内容" class="layui-textarea"></textarea>
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">标题图片</label>
			<div class="layui-input-block" style="padding-left: 20px">
	            <button class="layui-btn" id="uploadImg" type="button">上传图片</button>
	            <div class="layui-upload-list">
					<img id="preview" class="layui-upload-img" width="120" height="100">
					<p id="errorText"></p>
				</div>
	        </div>
		</div>
		<input type="hidden" name="title_img" id='title_img'>
		<button id="addBtn" type="button" class="layui-btn" lay-filter="add" lay-submit>确定发布</button>
    </form>
</div>

	</div>
	<div class="footer">

		<div class="footer-content-a">
			<dl>
                <dt><b>权益</b></dt>
                <dd>许可协议：xxx</dd>
                <dd>版权所有：xxx</dd>
                <dd>网站备案：xxx</dd>
                <dd>联系邮箱：1692145479@qq.com</dd>
        	</dl>
		</div>

		<div class="footer-content-b">
			<dl>
                <dt><b>架构</b></dt>
                <dd>项目名称：<a rel="nofollow" href="#" target="_blank">myForum</a></dd>
                <dd>版本分支：v1.0</dd>
                <dd>项目作者：<a href="#">printhzf</a></dd>
            </dl>
		</div>

		<div class="footer-content-c">
			<dl>
                <dt><b>统计</b></dt>
                <dd>文章总数：xx</dd>
                <dd>评论总数：xxx</dd>
                <dd>登录用户：xxx</dd>
            </dl>
		</div>

	</div>
	
<script type="text/javascript">
    layui.use(['form','jquery','layer','upload'], function () {
        var form   = layui.form,
	        $      = layui.jquery,
	        upload = layui.upload,
	        layer  = layui.layer;
        // form.verify({
        //     //支持函数式/数组的形式
        //     title: function(value, item){ //value：表单的值、item：表单的DOM对象
        //         if(!new RegExp("^[a-zA-Z0-9_\u4e00-\u9fa5\\s·]+$").test(value)){
        //             return '标题不能有特殊字符';
        //         }
        //         if( /^[\S]{5,25}$/.test(value)){
        //             return '标题必须5到25位，且不能出现空格';
        //         }
        //         if(/^\d+\d+\d$/.test(value)){
        //             return '用户名不能全为数字';
        //         }
        //     }
          
        // });   
        //普通图片上传
		var uploadInst = upload.render({
			elem: '#uploadImg'
			,url: 'upload'
			,before: function(obj){
				//预读本地文件示例，不支持ie8
				obj.preview(function(index, file, result){
					$('#preview').attr('src', result); //图片链接（base64）
				});
				$('#errorText').html("");
			}
			,done: function(res){
				if(res.code == 200){
					// 上传成功
					layer.msg('上传成功');
					$("#title_img").val(res.msg);
				}else{
					// 上传失败
					var errorText = $('#errorText');
					errorText.html('<span style="color: #FF5722;">'+res.msg+'请重新选择！</span> ');
					errorText.find('.demo-reload').on('click', function(){
						uploadInst.upload();
					});
				}
			}
			,error: function(){
				//演示失败状态，并实现重传
				var errorText = $('#errorText');
				errorText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
				errorText.find('.demo-reload').on('click', function(){
					uploadInst.upload();
				});
			}
		});
       
        //添加表单监听事件,提交注册信息
        form.on('submit(add)', function() {
        	var data = $("#form_topics").serialize();
            $.ajax({
                url    : 'save',
                type   : 'post',
                data   :  data,
                before : function(){}, 
                success: function(res){
                    if (res.code == 200) {
                        layer.msg(res.msg);
                        $('#preview').removerAttr('src');
                        $(":input","#form_topics").val("");
                    }else {
                        layer.msg(res.msg);
                        setTimeout( function(){
                        	window.location.reload()
                        },1000);
                    }
                }
            })
            //防止页面跳转
            return false;
        });
 
    });	
</script>

</body>
</html>