-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1:3306
-- 生成日期： 2018-11-16 08:51:18
-- 服务器版本： 5.7.23
-- PHP 版本： 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `myforum`
--
CREATE DATABASE IF NOT EXISTS `myforum` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `myforum`;

-- --------------------------------------------------------

--
-- 表的结构 `categories`
--
-- 创建时间： 2018-11-16 01:32:04
-- 最后更新： 2018-11-16 01:32:04
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL COMMENT '板块名称',
  `sort` int(11) NOT NULL COMMENT '版块目排序',
  `status` tinyint(4) NOT NULL COMMENT '状态（1：启用；0：禁用）',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '描述',
  `create_time` int(10) NOT NULL,
  `update_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文章版块表';

--
-- 插入之前先把表清空（truncate） `categories`
--

TRUNCATE TABLE `categories`;
--
-- 转存表中的数据 `categories`
--

INSERT INTO `categories` (`id`, `name`, `sort`, `status`, `description`, `create_time`, `update_time`) VALUES
(1, '技术类', 0, 0, '记录开发过程中遇到的问题与解决方案', 0, 0),
(2, '生活类', 0, 0, '记录生活中遇到的趣事与亮点', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `think_auth_group`
--
-- 创建时间： 2018-11-16 01:18:17
-- 最后更新： 2018-11-16 01:18:18
--

DROP TABLE IF EXISTS `think_auth_group`;
CREATE TABLE IF NOT EXISTS `think_auth_group` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '' COMMENT '用户组名称',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
  `rules` char(80) NOT NULL DEFAULT '' COMMENT '用户组对应的权限id（控制器方法的id）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='角色权限表';

--
-- 插入之前先把表清空（truncate） `think_auth_group`
--

TRUNCATE TABLE `think_auth_group`;
--
-- 转存表中的数据 `think_auth_group`
--

INSERT INTO `think_auth_group` (`id`, `title`, `status`, `rules`) VALUES
(1, '超级管理员', 1, '1,2'),
(2, '普通管理员', 1, '1,2'),
(15, 'test', 1, '1,2');

-- --------------------------------------------------------

--
-- 表的结构 `think_auth_group_access`
--
-- 创建时间： 2018-11-16 01:18:17
-- 最后更新： 2018-11-16 01:18:18
--

DROP TABLE IF EXISTS `think_auth_group_access`;
CREATE TABLE IF NOT EXISTS `think_auth_group_access` (
  `uid` mediumint(8) UNSIGNED NOT NULL COMMENT '用户ID',
  `group_id` mediumint(8) UNSIGNED NOT NULL COMMENT '用户组ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='角色表';

--
-- 插入之前先把表清空（truncate） `think_auth_group_access`
--

TRUNCATE TABLE `think_auth_group_access`;
--
-- 转存表中的数据 `think_auth_group_access`
--

INSERT INTO `think_auth_group_access` (`uid`, `group_id`) VALUES
(1, 1),
(2, 2),
(4, 1),
(5, 2),
(6, 2),
(22, 1);

-- --------------------------------------------------------

--
-- 表的结构 `think_auth_rule`
--
-- 创建时间： 2018-11-16 01:18:18
-- 最后更新： 2018-11-16 01:18:18
--

DROP TABLE IF EXISTS `think_auth_rule`;
CREATE TABLE IF NOT EXISTS `think_auth_rule` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '' COMMENT '控制器下的方法名',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '方法中文名',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '认证方式，1为实时认证；2为登录认证。',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：为1正常，为0禁用',
  `condition` char(100) NOT NULL DEFAULT '' COMMENT '规则表达式，为空表示存在就验证，不为空表示按照条件验证',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='权限表';

--
-- 插入之前先把表清空（truncate） `think_auth_rule`
--

TRUNCATE TABLE `think_auth_rule`;
--
-- 转存表中的数据 `think_auth_rule`
--

INSERT INTO `think_auth_rule` (`id`, `name`, `title`, `type`, `status`, `condition`) VALUES
(1, '/cms/User/UserList', '用户列表', 1, 1, ''),
(2, '/cms/Tool/uploadImg', '图片上传', 1, 1, '');

-- --------------------------------------------------------

--
-- 表的结构 `topics`
--
-- 创建时间： 2018-11-16 01:51:44
-- 最后更新： 2018-11-16 01:51:44
--

DROP TABLE IF EXISTS `topics`;
CREATE TABLE IF NOT EXISTS `topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '帖子标题',
  `title_img` varchar(200) COLLATE utf8_unicode_ci NOT NULL COMMENT '标题图片',
  `body` text COLLATE utf8_unicode_ci NOT NULL COMMENT '帖子内容',
  `is_top` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `is_hot` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否热门',
  `user_id` int(11) UNSIGNED NOT NULL COMMENT '用户ID',
  `category_id` int(11) UNSIGNED NOT NULL COMMENT '分类ID',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '标签',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '显示状态（1：显示；0：隐藏）',
  `view_count` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '查看总数',
  `reply_count` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '回复数量',
  `last_reply_user_id` int(11) UNSIGNED NOT NULL DEFAULT '0' COMMENT '最后回复的用户ID',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '更新时间',
  `order` int(11) NOT NULL DEFAULT '0' COMMENT '用于排序',
  `excerpt` text COLLATE utf8_unicode_ci COMMENT '用于SEO优化',
  `slug` int(11) DEFAULT NULL COMMENT 'SEO友好URL',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='文章内容表';

--
-- 插入之前先把表清空（truncate） `topics`
--

TRUNCATE TABLE `topics`;
-- --------------------------------------------------------

--
-- 表的结构 `user`
--
-- 创建时间： 2018-11-16 01:18:18
-- 最后更新： 2018-11-16 01:18:19
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `headimg` varchar(100) COLLATE utf8_unicode_ci DEFAULT '0' COMMENT '用户头像',
  `userip` int(10) NOT NULL COMMENT '注册IP',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（0-冻结，1-正常）',
  `create_time` int(10) DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) DEFAULT '0' COMMENT '更新时间',
  `last_login_ip` int(10) DEFAULT '0' COMMENT '上次登录IP',
  `last_login_time` int(10) DEFAULT '0' COMMENT '上次登录时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 插入之前先把表清空（truncate） `user`
--

TRUNCATE TABLE `user`;
--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `headimg`, `userip`, `status`, `create_time`, `update_time`, `last_login_ip`, `last_login_time`) VALUES
(1, 'printhzf', '1', '111@qq.com', '0', 0, 1, 0, 0, 0, 0),
(2, '2', 'c81e728d9d4c2f636f067f89cc14862c', '222@qq.com', '0', 0, 1, 0, 0, 2130706433, 1542251732),
(4, 'test', 'e10adc3949ba59abbe56e057f20f883e', 'test@qq.com', '0', 0, 1, 0, 0, 0, 0),
(5, 'test2', 'e10adc3949ba59abbe56e057f20f883e', 'test2@qq.com', '0', 0, 1, 0, 0, 0, 0),
(6, 'test3', 'e10adc3949ba59abbe56e057f20f883e', 'test3@qq.com', '0', 0, 1, 0, 0, 0, 0),
(22, '3', '3', '3', '0', 0, 1, 0, 0, 0, 0),
(24, '0', '0', 'cfcd208495d565ef66e7dff9f98764da', '0', 2130706433, 1, 1542185924, 1542185924, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `user_collect`
--
-- 创建时间： 2018-11-16 01:36:18
-- 最后更新： 2018-11-16 01:36:18
--

DROP TABLE IF EXISTS `user_collect`;
CREATE TABLE IF NOT EXISTS `user_collect` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topics_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='用户收藏表';

--
-- 插入之前先把表清空（truncate） `user_collect`
--

TRUNCATE TABLE `user_collect`;
-- --------------------------------------------------------

--
-- 表的结构 `user_comments`
--
-- 创建时间： 2018-11-16 01:43:10
-- 最后更新： 2018-11-16 01:43:10
--

DROP TABLE IF EXISTS `user_comments`;
CREATE TABLE IF NOT EXISTS `user_comments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topics_id` int(11) NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL COMMENT '评论内容',
  `rely_id` int(11) NOT NULL COMMENT '回复ID（用于叠楼）',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态（1：显示；0：隐藏）',
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='评论表';

--
-- 插入之前先把表清空（truncate） `user_comments`
--

TRUNCATE TABLE `user_comments`;
-- --------------------------------------------------------

--
-- 表的结构 `user_like`
--
-- 创建时间： 2018-11-16 01:34:52
-- 最后更新： 2018-11-16 01:34:52
--

DROP TABLE IF EXISTS `user_like`;
CREATE TABLE IF NOT EXISTS `user_like` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topics_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='用户点赞表';

--
-- 插入之前先把表清空（truncate） `user_like`
--

TRUNCATE TABLE `user_like`;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
