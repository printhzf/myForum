<?php 
namespace app\admin\common\model;

use think\Model;

class Categories extends Model 
{
	
	protected $pk = 'id';
	protected $table = 'categories';

}