<?php 
namespace app\admin\common\model;

use think\Model;

class User extends Model 
{
	protected $pk = 'id';
	protected $table = 'user';

	public function topics(){
		return $this->hasMany('Topics');
	}
}