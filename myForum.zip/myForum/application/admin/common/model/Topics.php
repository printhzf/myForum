<?php 
namespace app\admin\common\model;

use think\Model;

class Topics extends Model 
{
	protected $pk = 'id';
	protected $table = 'topics';

	protected $autoWriteTimestamp = true;
	// 创建时间字段
  	protected $createTime = 'create_time';
  	// 更新时间字段
    protected $updateTime = 'update_time';
	// 时间字段取出后的默认时间格式
	protected $dateFormat = 'Y-m-d H:i:s';

	// 开启自动设置
	protected $auto = [];
	// 仅在新增有效
	protected $insert = ['create_time','status'=>1];
	// 仅在更新有效
	protected $updtae = ['update_time'];
	// 忽略数据表不存在的字段
	protected $field = true;

	// 帖子状态获取器
	public function getStatusAttr($value)
	{
		$status = ['1'=>'显示', '0'=>'隐藏'];
		return $status[$value];
	}

	// 获取帖子简介
	public function getBrief()
	{
		
	}

	public function user(){
		return $this->belongsTo('User');
	}
}