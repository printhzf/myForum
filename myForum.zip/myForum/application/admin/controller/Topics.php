<?php 
namespace app\admin\controller;

use app\admin\common\controller\Base;
use app\admin\common\model\Topics as TopicsModel;
use think\facade\Request;
use think\facade\Session;

class Topics extends Base 
{
	public function add(){
		// 登录才允许发布
		// $this->isLogin();
		// 设置页面标题
		// 获取下一个栏目的信息
		// 发布界面渲染
		return $this->fetch();
	}

	public function save(){

	}
}