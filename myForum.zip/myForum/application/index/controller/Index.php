<?php
namespace app\index\Controller;

use app\common\controller\Base;
use app\admin\common\model\Categories;
use app\admin\common\model\Topics;
use think\facade\Request; //导入请求静态代理
use think\Db;

class Index extends Base
{
    // 首页
    public function index()
    {
        
       //设置全局查询条件
        $map = [];  //将当前页面的全部查询条件封装到一个条件数组中
        // 条件1:显示状态必须为1
        $map[] = ['title_status','=',1];  //等号必须要有,不允许省略

        //实现搜索功能
        $keywords = Request::param('keywords');
        if (!empty($keywords)){
            //条件2: 模糊匹配查询条件
            $map[] = ['title' , 'like','%'.$keywords.'%'];
        }

        //分类信息显示
        //1.获取到URL中的分类ID
        $cateId = Request::param('cate_id');
        //如果当前存在分类ID,再进行查询获取到分类名称
        if (isset($cateId)){
            //条件3: 当前列表与当前栏目id对应,此时$map[]条件数组生成完毕
            $map[] = ['category_id','=', $cateId];
            //文章列表分页显示,分页仅显示5条
            $topicsList = Topics::alias('t')->join('user u','t.user_id = u.id')
                            ->field('t.*,u.username')
                            ->where($map)->order('create_time','desc')->select(); 
            $res = Categories::get($cateId);
            $this->view->assign('cateName',$res->name);

        } else {
            //如果当前没有分类ID,就是首页啦
            $topicsList = Topics::alias('t')->join('user u','t.user_id = u.id')
                            ->field('t.*,u.username')
                            ->where($map)->order('create_time','desc')->select();
            $this->view->assign('cateName','全部帖子');
           
        }
        // 导航栏文章分类
        $cateList = Categories::all();
        $this->view->assign('cateList',$cateList);

        // 热门帖子
        $hotList = Topics::where('is_hot','1')->field('id,title')->order('create_time','desc')->select(); 
        $this->view->assign('hotList',$hotList);

        // 帖子列表
        $this->view->assign('topicsList',$topicsList->toArray());

        // 渲染首页模板
        return $this->fetch();
    }

    public function add(){

        // 登录才允许发布
        // $this->isLogin();

        // 设置页面标题
        $this->view->assign('title','帖子发布');
        // 获取下一个栏目的信息
        // 导航栏文章分类
        $cateList = Categories::all();
        $this->view->assign('cateList',$cateList);
        // 发布界面渲染
        return $this->fetch();
    }

    public function upload(){
        // 上传标题图片
        $file = Request::file('file');
        if(!empty($file)) {  
            // 将文件移动到框架应用目录/public/upload/ 目录下
            $info = $file->validate([
                        'size'=>1567800,
                        'ext'=>'jpg,png,gif'
                    ])->move('upload/'); 
            if($info) {
                return json(array('code' => 200, 'msg' =>$info->getSaveName()));//文件的位置以及文件名
            }else{
                // 上传失败获取错误信息
                return json(array('code' => 0, 'msg' =>$file->getError()));
            } 
        }
    }
    
    // 图片处理

    public function save(){
        if(Request::isPost()){
            // 获取数据
            $data = Request::post();
            $res  = $this->validate($data,'app\common\validate\Topics');
            if(true !== $res){
                // echo '<script>alert("'.$res.'");location.back();</script>';
                return json(array('code' => 0, 'msg' =>$validate->getError()));
            }else{
                // 保存数据
                $topics = new Topics();
                $res = $topics->save($data);
                if($res){
                    return json(array('code' => 200, 'msg' =>'发布成功！'));
                }else{
                    return json(array('code' => 0, 'msg' =>'发布失败！'));
                }
            }
        }else{
            return json(array('code' => 0, 'msg' =>'请求类型错误'));
        }
    }

    // 详情页
    public function details()
    {
        $topic_id = Request::param('topic_id');
         //文章列表分页显示,分页仅显示5条
        $topic = Topics::alias('t')->join('user u','t.user_id = u.id')
                    ->field('t.*,u.username')
                    ->order('create_time','desc')->find($topic_id); 
        // 导航栏文章分类
        $cateList = Categories::all();
        $this->view->assign('cateList',$cateList);
        $this->view->assign('topic',$topic);
        return $this->fetch();
    }

    // 用户收藏
    public function collect() 
    {  

    }

}