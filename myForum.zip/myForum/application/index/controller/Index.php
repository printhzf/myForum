<?php
namespace app\index\Controller;

use app\common\controller\Base;
use app\admin\common\model\Categories;
use think\facade\Request; //导入请求静态代理

class Index extends Base
{
    // 首页
    public function index()
    {
        // 导航栏文章分类
        $list = Categories::all();
        $this->assign('list',$list);
        // 渲染首页模板
        return $this->fetch();
    }

    // 详情页
    public function detail()
    {

    }

    // 用户收藏
    public function collect() 
    {  

    }

}