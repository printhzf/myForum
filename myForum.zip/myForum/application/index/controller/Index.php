<?php
namespace app\index\Controller;

use app\common\controller\Base;
use app\admin\common\model\Categories;
use app\admin\common\model\Topics;
use think\facade\Request; //导入请求静态代理

class Index extends Base
{
    // 首页
    public function index()
    {
        
       //设置全局查询条件
        $map = [];  //将当前页面的全部查询条件封装到一个条件数组中
        // 条件1:显示状态必须为1
        $map[] = ['status','=',1];  //等号必须要有,不允许省略

        //实现搜索功能
        $keywords = Request::param('keywords');
        if (!empty($keywords)){
            //条件2: 模糊匹配查询条件
            $map[] = ['title' , 'like','%'.$keywords.'%'];
        }

        //分类信息显示
        //1.获取到URL中的分类ID
        $cateId = Request::param('cate_id');
        //如果当前存在分类ID,再进行查询获取到分类名称
        if (isset($cateId)){
            //条件3: 当前列表与当前栏目id对应,此时$map[]条件数组生成完毕
            $map[] = ['category_id','=', $cateId];
            $res = Categories::get($cateId);
            //文章列表分页显示,分页仅显示5条
            $topicsList = Topics::where($map)->order('create_time','desc')->paginate(5); 
            $this->view->assign('cateName',$res->name);
          
        } else {
            //如果当前没有分类ID,就是首页啦
            $this->view->assign('cateName','全部帖子');
            $topicList = Topics::where($map)->order('create_time','desc')->paginate(5); 
        }

        // 导航栏文章分类
        $catelist = Categories::all();
        $this->view->assign('catelist',$catelist);

        // 渲染首页模板
        return $this->fetch();
    }

    public function add(){

        // 登录才允许发布
        // $this->isLogin();
        // 设置页面标题
        $this->view->assign('title','帖子发布');
        // 获取下一个栏目的信息
        $catelist = Categories::all();

        // 导航栏文章分类
        $this->view->assign('catelist',$catelist);
        // 发布界面渲染
        return $this->fetch();
    }

    public function upload(){

    }

    public function save(){
        if(Request::isPost()){
            // 获取数据
            $data = Request::post();
            $res  = $this->validate($data,'app\common\validate\Topics');
            if(true !== $res){
                // echo '<script>alert("'.$res.'");location.back();</script>';
                return json(array('code' => 0, 'msg' =>$validate->getError()));
            }else{
                // 上传标题图片
                $file = Request::file('title_img');
                if(!empty($file)) {  
                   // 将文件移动到框架应用目录/public/upload/ 目录下
                    $info = $file->validate([
                                'size'=>15678,
                                'ext'=>'jpg,png,gif'
                            ])->move(ROOT_PATH.'public'.DS.'upload'); 
                    if($info) {
                        // 成功上传 获取上传信息
                        $data['title_img'] = $info->getSaveName(); //文件的位置以及文件名
                    }else{
                        // 上传失败获取错误信息
                        $this->error($file->getError());
                    } 
                }
                // 保存数据
                $topics = new Topics();
                $res = $topics->allowField(['title','title_img','user_id','category_id'])->isUpdate(false)->save();
                if($res){
                    return json(array('code' => 200, 'msg' =>'发布成功！'));
                }else{
                    return json(array('code' => 0, 'msg' =>'发布失败！'));
                }
            }
        }else{
            return json(array('code' => 0, 'msg' =>'请求类型错误'));
        }
    }

    // 详情页
    public function detail()
    {

    }

    // 用户收藏
    public function collect() 
    {  

    }

    /*****
     *  结合layui的文件上传
     *  1.上传文件格式校验
     *  2.上传参数校验
     *
     */
    public function uploadImg($request) {
        $status = 0;
        $data = [];
        $file = request()->file('file'); 
        if(empty($file)) {  
            $message = '请选择上传文件';  
        }  
        // 将文件移动到框架应用目录/public/upload/ 目录下
        $info = $file->validate(['size'=>15678,'ext'=>'jpg,png,gif'])
                     ->move(ROOT_PATH.'public'.DS.'upload'); 
        if($info) {
            // 成功上传 获取上传信息
            // $info->getExtension(); // 文件名的后缀
            $data['url'] = $info->getSaveName(); //文件的位置以及文件名
            $status  = 1;
            $message = '文件上传成功！';
        }else{
            // 上传失败获取错误信息
            $message = $file->getError();
        }
        return self::showMsg($status, $message, $data);
    }

    public function uploadFile(Request $request) {
        $status = 0;
        $data = [];
        $file = request()->file('file'); 
        if(empty($file)) {  
            $message = '请选择上传文件';  
            $status = 3;
        }  
        $info = $file->move(ROOT_PATH.'public'.DS.'upload'); 
        if($info){
            $status  = 1;
            $data['url'] = $info->getSaveName();
            $message = '文件上传成功！';
            // $uploadFile = new Uploadfile();
            // $uploadFile->userid = 1;
            // $uploadFile->filename = $file_name;
            // $uploadFile->path = $fileUrl;
            // $uploadFile->save();
        }else{
            $message = $file->getError();
        }
        
        return self::showMsg($status, $message, $data);
    }

    public static function showMsg($status, $message, $data = array()) {
        $result = array(
            'status'  => $status,
            'message' => $message,
            'data'    => $data
        );
        return json($result);
    }

}