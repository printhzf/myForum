<?php
namespace app\index\controller;

use think\facade\Request;  //导入请求静态代理
use think\facade\Session;  //导入SESSION静态代理

use app\common\controller\Base; //导入公共控制器
use app\common\model\User as UserModel; //导入User模型并取别名
use app\common\validate\User as UserValidate; //导入User验证器并取别名

class User extends Base
{
	// 登录页
	public function login(){
        $this->isRelogin();
		return $this->fetch();
	}

	// 验证码校验
	public function check(){
        $captcha = Request::param('verify');
        if(!captcha_check($captcha)){
            //验证码错误
            return false;
        }else{
             //验证码正确
        	return true;
        }
    }

    //验证用户登录
	public function checkLogin(){
		if(Request::isAjax()) {
            if(self::check()) {
                $res = [];
                $data = Request::param();
                $validate = new UserValidate();
                if (!$validate->scene('login')->check($data)) {
                    $res = ['code'=>0,'msg'=>$validate->getError()];
                } else {
                    $map['username'] = $data['username'];
                    $map['password'] = md5($data['password']);
                    $obj = UserModel::where($map)->field('id,username,status,headimg')->find();
                    if (!empty($obj)) {
                        $user = $obj->toArray();
                        if ($user['status'] != '启用'){
                            $res = ['code'=>0,'msg'=>'当前用户已禁用！'];
                        } else {
                            Session::set('userId', $user['id']);
                            Session::set('userName', $user['username']);
                            Session::set('userImg', $user['headimg']);
                            UserModel::where($map)->update(
                                [
                                    'last_login_time' => time(),
                                    'last_login_ip'   => ip2long($_SERVER["REMOTE_ADDR"]),
                                ]
                            );
                            $res = ['code'=>200,'msg'=>'登录成功！'];
                        }
                    } else {
                        $res = ['code'=>0,'msg'=>'用户名或密码错误！'];
                    }
                }
            } else {
                $res = ['code'=>0,'msg'=>'验证码错误！'];
            }
            return json($res);
        }
	}

    // 退出登录
    public function logout(){
        //1.清除全部session
        Session::clear();
        //2.退出登录并跳转到登录页面
        $this->redirect('index/index/index');
    }

    // 注册页
    public function register(){
    	return $this->fetch();
    }

    // 添加用户
    public function create(){
        if(Request::isAjax()){
            $data = Request::param();
            $validate = new UserValidate();
            if (!$validate->scene('register')->check($data)) {
                Session::set('register_email', $data['email']);
                Session::set('register_name', $data['username']);
                Session::set('register_pass', $data['password']);
                return json(array('code' => 0, 'msg' =>$validate->getError()));
            } else {
                $user  = new UserModel();
                $data['userip'] = $_SERVER["REMOTE_ADDR"];
                $user->data($data,true); //批量修改
                $state = $user->allowField(['username','password','email','userip'])->isUpdate(false)->save();
                if ($state == 1){
                    return json(array('code' => 200, 'msg' => '注册成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '注册失败'));
                }
            }
        }
    }

    // 用户编辑
    public function editpage(){
        return $this->fetch();
    }


    /*****
     *  结合layui的文件上传
     *  1.上传文件格式校验
     *  2.上传参数校验
     *
     */
    public function uploadImg($request) {
        $status = 0;
        $data = [];
        $file = request()->file('file'); 
        print_r($file);exit;
        if(empty($file)) {  
            $message = '请选择上传文件';  
        }  
        // 将文件移动到框架应用目录/public/upload/ 目录下
        $info = $file->validate(['size'=>15678,'ext'=>'jpg,png,gif'])
                     ->move(ROOT_PATH.'public'.DS.'upload'); 
        if($info) {
            // 成功上传 获取上传信息
            // $info->getExtension(); // 文件名的后缀
            $data['url'] = $info->getSaveName(); //文件的位置以及文件名
            $status  = 1;
            $message = '文件上传成功！';
            // $uploadFile = new Uploadfile();
            // $uploadFile->userid = $user;
            // $uploadFile->filename = $info->getFilename();
            // $uploadFile->path = $fileUrl;
            // $uploadFile->save();
        }else{
            // 上传失败获取错误信息
            $message = $file->getError();
        }
        return self::showMsg($status, $message, $data);
    }

    public function uploadFile(Request $request) {
        $status = 0;
        $data = [];
        $file = request()->file('file'); 
        if(empty($file)) {  
            $message = '请选择上传文件';  
            $status = 3;
        }  
        $info = $file->move(ROOT_PATH.'public'.DS.'upload'); 
        if($info){
            $status  = 1;
            $data['url'] = $info->getSaveName();
            $message = '文件上传成功！';
            // $uploadFile = new Uploadfile();
            // $uploadFile->userid = 1;
            // $uploadFile->filename = $file_name;
            // $uploadFile->path = $fileUrl;
            // $uploadFile->save();
        }else{
            $message = $file->getError();
        }
        
        return self::showMsg($status, $message, $data);
    }

    public static function showMsg($status, $message, $data = array()) {
        $result = array(
            'status'  => $status,
            'message' => $message,
            'data'    => $data
        );
        return json($result);
    }

}
