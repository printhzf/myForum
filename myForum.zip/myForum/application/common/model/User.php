<?php
namespace app\common\model;

use think\Model;

class User extends Model
{
  // 设置当前模型的数据库连接
  protected $connection = [
    // 数据库类型
    'type'     => 'mysql',
    // 服务器地址
    'hostname' => '127.0.0.1',
    // 数据库名
    'database' => 'myforum',
    // 数据库用户名
    'username' => 'root',
    // 数据库密码
    'password' => '',
    // 数据库编码默认采用utf8
    'charset'  => 'utf8',
    // 数据库表前缀
    'prefix'   => '',
    // 自动写入时间戳字段
    'auto_timestamp'  => true,
    // 时间字段取出后的默认时间格式
    // 'datetime_format' => false,
    'datetime_format' => 'Y-m-d H:i:s',
    // 数据库调试模式
    'debug'    => false,
  ];

  // 默认主键
  protected $pk = 'id';  
  // 默认数据表
  protected $table = 'user';  

  // 自动写入时间戳
  protected $autoWriteTimestamp = true;
  // 定义时间戳字段名:默认为create_time和create_time,如果一致可省略
  // 如果想关闭某个时间戳字段,将值设置为false即可:$create_time = false
  // 创建时间字段
  protected $createTime = 'create_time';
  // 更新时间字段
  protected $updateTime = 'update_time';


  // public function thinkAuthGroupAccess()
  // {
  //   return $this->hasOne('Think_auth_group_access','uid');
  // }

  // 用户状态获取器
  public function getStatusAttr($value)
  {
    $status = ['1'=>'启用', '0'=>'禁用'];
    return $status[$value];
  }

  // 用户密码修改器
  public function setPasswordAttr($value)
  {
    return md5($value);
  }

  // 用户IP修改器
  protected function setUseripAttr()
  {
    return ip2long($_SERVER["REMOTE_ADDR"]);
  }


    // protected function setPasswordAttr($value)
    // {
    //     return password_hash_tp($value);
    // }

    // /**
    //  * 修改密码
    //  */
    // public function updatePassword($uid, $password)
    // {
    //     return $this->where("id", $uid)->update(['password' => password_hash_tp($password)]);
    // }
    

}
