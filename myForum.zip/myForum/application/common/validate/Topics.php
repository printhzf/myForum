<?php
namespace app\common\validate;

use think\Validate;

class Topics extends Validate
{

    // 验证规则
    protected $rule = [
        'title|标题'     => 'require|length:5,20|chsAlphaNum',
        'body|内容'      => 'require',
        'user_id|作者ID' => 'require',
        'category_id|栏目名称' => 'require',
    ];

    // 提示信息
    protected $message = [
        'title.require'  => '标题必须',
        'body.require'   => '内容必须',
        'user_id.require'     => '作者必须',
        'category_id.require' => '栏目必须',
        'title.length'   => '标题在5位到20位之间',
    ];

}
