<?php
namespace app\common\validate;

use think\Validate;

class Categories extends Validate
{

    // 验证规则
    protected $rule = [
        'name|标题'     => 'require|length:5,20|chsAlpha',
    ];

    // 提示信息
    protected $message = [
        'name.require'  => '标题必须',
        'name.length'   => '标题在5位到20位之间',
    ];

}
