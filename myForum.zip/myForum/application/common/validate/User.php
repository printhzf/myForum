<?php
namespace app\common\validate;

use think\Validate;

class User extends Validate
{
    // 应用场景
    protected $scene = [
        'register' => ['username','password','resure','email'],
        'login'    => ['username'=>'require|token','password'=>'require'],
    ];

    protected $regex = [
      'mobile'    => '^1(3[0-9]|4[57]|5[0-35-9]|7[0135678]|8[0-9])\\d{8}$',
      'password'  => '/^[\w]{6,15}$/'
    ];

    // 验证规则
    protected $rule = [
        'username'  => 'require|unique:user|length:4,26|token',
        'password'  => 'confirm:resure|length:6,16',
        'resure'    => 'confirm:password',
        'email'     => 'require|unique:user|email',
        '__token__' => 'token',
    ];

    // 提示信息
    protected $message = [
        'username.require' => '名称必须',
        'password.require' => '密码必须',
        'email.require'    => '邮箱必须',
        'username.length'  => '用户名在4位到26位之间',
        'password.length'  => '密码在6位到16位之间',
        'email.email'      => '邮箱格式错误',
        'username.unique'  => '用户名已存在',
        'email.unique'     => '邮箱已存在',
        'resure.confirm'   => '两次输入密码不一致',
        'password.confirm' => '两次输入密码不一致',
    ];

    // 字段描述
    protected $field = [
        'username'  => '用户名',
        'password'  => '密码',
        'resure'    => '二次密码',
        'email'     => '邮箱',
    ];

    // 自定义验证规则
    protected function checkName($value,$rule,$data){
        return $rule == $value ? true : '名称必须是hzf';
    }

}
