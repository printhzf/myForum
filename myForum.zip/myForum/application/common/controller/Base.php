<?php
namespace app\common\controller;

use think\auth\Auth;
use think\Controller;
use think\Facade\Session;
use think\facade\Request;

/**
* 该控制器继承自Controller.php
* 用户控制器应继承自这个基础公共控制器
* 用户可以将一些公共操作放在这个公共控制器
*/
class Base extends Controller
{
	/**
	 * 初始化方法
	 * 1.在所有方法之前调用
	 * 2.常用来创建常量,公共方法等
	 */
	protected function initialize()
	{

	}

	protected function checkAuth()
	{
		$module = Request::module();
        $controller = Request::controller();
        $action = Request::action();
        $rule = strtolower($module.'/'.$controller.'/'.$action);
        $auth = new Auth();
        $no_check = [
        	'index/index/index',
        ];
        if(!in_array($rule,$no_check)){
        	if(!$auth->check($rule, session('uid'))){
           		$this->error('你没有权限访问','/index/index/index');
        	}
        }

	}

	// 是否登录
	protected function isLogin()
	{
		if(!Session::has('userId')){
			return $this->error('您还没有登录！','user/login');
		}
	}

	// 是否重复登录
	protected function isRelogin()
	{
		if(Session::has('userId')){
			return $this->error('您已经登录！','index/index');
		}
	}
}