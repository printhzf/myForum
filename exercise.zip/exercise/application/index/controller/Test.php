<?php
namespace app\index\controller;
use think\facade\Cache;
use think\Db;
use Redis;

class Test
{

    public function redis()
	{
		$redis = new Redis();
		$redis->connect('127.0.0.1', 6379);
		// $redis->auth('password'); # 如果没有密码则不需要这行
		$redis->flushALL();
		// 字符串操作
		// $this->keyAction($redis);
		// $this->listAction($redis);
		// $this->setAction($redis);
		$this->sortedSetAction($redis);
		
		show($redis->DBSIZE());
	}

	public function keyAction($redis) {

		$redis->set('key1','value1');
		$key1 = $redis->get('key1');
		$keys = $redis->keys('*');
		if($redis->exists('key1')) $redis->del('key1'); 
		show($redis->get('key1'));
	}

	public function stringAction($redis) {

	}

	public function hashAction($redis) {
		
	}

	public function listAction($redis) {
		// 将数据一一加入到列表中
		$redis->LPUSH('list', 30);
		$redis->LPUSH('list', 1.5);
		$redis->LPUSH('list', 10);
		$redis->LPUSH('list', 8);
		$redis->RPUSH('list', 40);
		$redis->RPUSH('list', 20);
		$redis->RPOP('list');
		show($redis->BLPOP('list'));
		show($redis->LRANGE('list',1,3));
		show($redis->SORT('list'));

	}

	public function setAction($redis) {
		$redis->SADD('set1','aaa','bbb','ccc');
		$redis->SADD('set2','eee','bbb','kkk');
		show($redis->SUNION('set1'));
		show($redis->sInter("set1", "set2"));
		show($redis->sDiff("set1", "set2"));
	}

	public function sortedSetAction($redis) {
		$redis->SADD('set1','aaa','bbb','ccc');
		$redis->ZADD('set1','iii');
		show($redis->SUNION('set1'));
	}

	public function getUserData($user_id)
	{
		if (!$data = Cache::store('redis')->get("user:{$user_id}")) {
			$data = Db::name('user')->where('id', $user_id)->find();

			Cache::store('redis')->set("user:{$user_id}", $data);
		}
		return $data;
	}

	
}
