<?php
namespace app\index\controller;

class Common
{
	protected $test = '111';
	
	protected function initialize($test) {
		$this->test = $test;
	}

	public static function testArrayFilp() {
		// 反转/交换数组中的键名和对应关联的键值。
		$a1 = array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
		$result = array_flip($a1);
		show($result);
	}

	public static function myfunction($v) {
		return($v*$v);
	}

	public static function testArrayMap() {
		// 将用户自定义函数作用到给定数组的每个值上，返回新的值。
		$a=array(1,2,3,4,5);
		show(array_map("self::myfunction",$a));
	}


}
