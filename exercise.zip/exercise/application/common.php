<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件

/**
 * 数据输出调试函数
 * @param  $var 输入参数
 * @return void 
 **/
function show($var, $isDump = false) {
	$func = $isDump ? 'var_dump' : 'print_r';
	echo '<hr/><br/>';
	if (empty($var)) {
		echo 'null';
	} else if (is_array($var) || is_object($var)) {
		echo '<pre>';
		$func($var);
	} else {
		echo $var;
	}
}
