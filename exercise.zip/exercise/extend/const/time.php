<?php

const SECOND = 1;
const MINUTE_SECOND = 60;
const HOUR_MINUTE = 60;
const HOUR_SECOND = 3600;
const DAY_SECOND = 86400;
const WEEK_SECOND = 604800;
const MONTH_SECOND = 2592000;
const YEAR_SECOND = 31104000;

const DAY_HOUR = 24;
const WEEK_DAY = 7;
const MONTH_DAY = 30;
const YEAR_MONTH = 12;
const YEAR_DAY = 360;
