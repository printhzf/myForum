//获取滚动条当前的位置 
function getScrollTop() { 
	var scrollTop = 0; 
	if (document.documentElement && document.documentElement.scrollTop) { 
		scrollTop = document.documentElement.scrollTop; 
	} 
	else if (document.body) { 
		scrollTop = document.body.scrollTop; 
	} 
	return scrollTop; 
};
//获取当前可是范围的高度 
function getClientHeight() { 
	var clientHeight = 0; 
	if (document.body.clientHeight && document.documentElement.clientHeight) { 
		clientHeight = Math.min(document.body.clientHeight, document.documentElement.clientHeight); 
	} 
	else { 
		clientHeight = Math.max(document.body.clientHeight, document.documentElement.clientHeight); 
	} 
	return clientHeight; 
};
//获取文档完整的高度 
function getScrollHeight() { 
	return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight); 
};
$("#gotop").click(function () {
    var speed=200;//滑动的速度
    $('body,html').animate({ scrollTop: 0 }, speed);
    return false;
});
$("#godown").click(function () {
	var height = getScrollHeight();
    var speed=200;//滑动的速度
    $('body,html').animate({ scrollTop: height }, speed);
    return false;
});

$(function(){
	$('.nav-list>li').each(function(){
		if ($(this).children('ul').length >0)
		{
			var i = $(this).find('i');
			i.addClass('fa-sort-up');
		}
	})
	$('.nav-list>li').hover(function(){
 		$(this).css('border-bottom','6px solid #1cbb9b');
 		var i = $(this).find('.fa-sort-up');
 		i.css('top', '18px');
 		i.addClass('fa-sort-down');
 		i.removeClass('fa-sort-up');
 		$(this).find('.nav-children').show();
	},function(){
		var i = $(this).find('.fa-sort-down');
 		i.css('top', '26px');
 		i.removeClass('fa-sort-down');
 		i.addClass('fa-sort-up');
 		$(this).find('.nav-children').hide();
		$(this).css('border-bottom','0');
	});
});