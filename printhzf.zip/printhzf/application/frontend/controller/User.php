<?php
namespace app\frontend\controller;

use app\model\Topic;
use app\model\User as UserModel;
use app\service\UserService;
use app\service\TopicService;
use app\common\validate\User as UserValidate;

use think\facade\Request;
use think\facade\Session; 
use think\Controller;
use think\Db;


class User extends Controller 
{
    // 登录页
	public function viewLogin() {
		return $this->fetch('login');
	}

	// 验证码校验
	public static function checkCaptcha() 
    {
        $captcha = Request::param('verify');
        if (captcha_check($captcha)) 
        {
            //验证码正确
            return true;
        }
    }

    // 退出登录
    public function logout() {
        UserService::logout();
        $this->redirect('index/index/index');
    }

    // 注册页
    public function viewRegister() {
    	return $this->fetch('register');
    }

    // 添加用户
    public function save() 
    {
        if (Request::isAjax()) 
        {
            $data = Request::param();
            $validate = new UserValidate();
            if (!$validate->scene('register')->check($data)) {
                Session::set('register_email', $data['email']);
                Session::set('register_name', $data['username']);
                Session::set('register_pass', $data['password']);
                return json(array('code' => 0, 'msg' =>$validate->getError()));
            } else {
                $user  = new UserModel();
                $data['user_ip'] = $_SERVER["REMOTE_ADDR"];
                $user->data($data,true); //批量修改
                $state = $user->allowField(['username','password','email','user_ip'])->isUpdate(false)->save();
                if ($state == 1){
                    return json(array('code' => 200, 'msg' => '注册成功'));
                } else {
                    return json(array('code' => 0, 'msg' => '注册失败'));
                }
            }
        }
    }

    // 个人档案 
    public function viewUserInfo() 
    {
        $userId   = Request::param('user_id');
        $page     = Request::param('page');
        $userInfo = UserModel::get($userId, $page);
        $timeline = self::getTimeline($userId);
        $this->view->assign('userInfo',$userInfo);
        $this->view->assign('timeline',$timeline);
        return $this->fetch('user_info');
    }

    // TODO：获取时间轴数据
    public static function getTimeline($userId, $page=1) 
    {
        $per = 6;
        $begin = ($page - 1) * $per;
        $limit = $begin != 0 ? "{$begin},{$per}" : $per;
        $param = [
            'field' => 'id, title, title_img, brief, reply_count, gmt_create',
            'map'   => [
                'user_id' => ['=', $userId]
            ],
            'limit' => $limit,
            'order' => 'gmt_create desc',
        ];
        $data = TopicService::read($param);
        return $data;
    }

    // 用户编辑
    public function viewUserEdit() 
    {
        return $this->fetch('edit');
    }

    // 未读消息
    public function viewNotification() 
    {
        
        $map['id'] = Request::param('user_id');
        $num = Db::table('notice')->where($map)->count();
        if ($num > 0) 
        {
            $list = Db::table('notice')->alias('n')->join('user u','n.user_id = u.id')
                ->field('n.*,u.username,u.head_img')->where($map)->order('gmt_create','desc')->select();
        
            foreach($list as $k => $v) 
            {
                $list[$k]['gmt_create']    = convertTime($v['gmt_create']);
                $list[$k]['reply_content'] = convertText($v['reply_content']);
            }

            // 未读通知数量归零
            UserModel::where($map)->update(['notification_count'=>0]);
            Session::set('userNc',0);

            $this->view->assign('list',$list);
        }
        
        return $this->fetch('notification');
    }

    /*****
     *  结合layui的文件上传
     *  1.上传文件格式校验
     *  2.上传参数校验
     *
     */
    public function uploadImg($request) 
    {
        $status = 0;
        $data = [];
        $file = request()->file('file'); 
        if(empty($file)) {  
            $message = '请选择上传文件';  
        }  
        // 将文件移动到框架应用目录/public/upload/ 目录下
        $info = $file->validate(['size'=>15678,'ext'=>'jpg,png,gif'])
                     ->move(ROOT_PATH.'public'.DS.'upload'); 
        if($info) {
            // 成功上传 获取上传信息
            // $info->getExtension(); // 文件名的后缀
            $data['url'] = $info->getSaveName(); //文件的位置以及文件名
            $status  = 1;
            $message = '文件上传成功！';
            // $uploadFile = new Uploadfile();
            // $uploadFile->userid = $user;
            // $uploadFile->filename = $info->getFilename();
            // $uploadFile->path = $fileUrl;
            // $uploadFile->save();
        } else {
            // 上传失败获取错误信息
            $message = $file->getError();
        }
        return showMsg($status, $message, $data);
    }

    public function uploadFile(Request $request) 
    {
        $status = 0;
        $data = [];
        $file = request()->file('file'); 
        if (empty($file)) {  
            $message = '请选择上传文件';  
            $status = 3;
        }  
        $info = $file->move(ROOT_PATH.'public'.DS.'upload'); 
        if ($info) {
            $status  = 1;
            $data['url'] = $info->getSaveName();
            $message = '文件上传成功！';
        } else {
            $message = $file->getError();
        }
        return showMsg($status, $message, $data);
    }

}
