<?php

namespace app\frontend\controller;

use app\service\UserService;
use app\service\ReplyService;
use app\service\TopicService;
use app\service\CategoryService;
use think\Controller;

class Common extends Controller
{
    public function categoryTree()
    {
        return $this->fetch('common/category_tree');
    }

    public function topicList()
    {
        return $this->fetch('common/topic_list');
    }

    public function breadCrumbs()
    {
    	$categoryTree = CategoryService::tree();
        $this->assign('categoryTree', $categoryTree);
        return $this->fetch('common/breadcrumbs');
    }

    public function footer()
    {
    	 // 帖子总数
        $topicCount = TopicService::count();
        $this->assign('topicCount', $topicCount);

        // 评论总数
        $replyCount = ReplyService::count(); 
        $this->assign('replyCount', $replyCount);

        // 用户总数
        $userCount = UserService::count(); 
        $this->assign('userCount', $userCount);

        return $this->fetch('common/footer');
    }

}