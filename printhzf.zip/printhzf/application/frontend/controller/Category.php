<?php
namespace app\frontend\controller;

use app\model\CategoryModel;
use think\facade\Request;
use think\Controller;

/**
 * 分类控制器
 */
class Category extends Controller
{
	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-16
	 * @Description: 获取面包屑导航
	 * ============================
	 */
	public function getBreadcrumbs($categoryId)
	{
		$child = CategoryModel::get(function($query) use ($categoryId) {
            $query->field('id,pid,category_name')->where('id', $categoryId);
        });
        if (!empty($child))
        {
            $pid = $child->toArray()['pid'];
            if ($pid != 0)
            {   
                $crumbs = CategoryModel::get(function($query) use ($pid) {
                    $query->field('id,pid,category_name')->where('id', $pid);
                })->toArray();
                $crumbs['node'] = $child->toArray();
            } else {
                $crumbs = $child;
            }
            return $crumbs;
        }
	}

	public static function getCategoryTree()
	{
		$list = CategoryModel::all(function($query) {
		            $query->field('id,pid,category_name')->order('sort asc');
		        })->toArray();
        $tree = getTree($list);
        return $tree;
	}
}