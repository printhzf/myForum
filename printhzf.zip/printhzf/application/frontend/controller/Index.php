<?php
namespace app\frontend\controller;

use app\frontend\controller\Base;
use app\frontend\controller\Topic;
use app\frontend\controller\Category;

// 业务逻辑
// 安全

/****************
 *  PrintHzf项目
 * 一、目的
 *  1.记录收获
 *  2.共享知识
 *  3.交流看法
 */
class Index extends Base
{
	// 网站首页
    public function index() 
    {
        $map = [];  // 设置全局查询条件
        $topicList = []; // 文章列表

        // 分类ID
        $categoryId = $this->request->param('category_id'); // 获取到URL中的分类ID
        // 页码
        $page = $this->request->param('page');
        // 关键字
        $keyword = $this->request->param('keyword');

        // 显示状态必须为1
        $map[] = ['title_status', '=', 1];   
        // 匹配文章分类
        if (!empty($categoryId))
        {
            $map[] = ['category_id' , '=', $categoryId]; 
            $category = new Category;
            $breadcrumbs= $category->getBreadcrumbs($categoryId);
            $this->assign('breadcrumbs', $breadcrumbs);
        }
        // 匹配搜索关键字
        if (!empty($keyword))
        {
            $map[] = ['title|brief' , 'like', "%{$keyword}%"]; 
            $this->assign('keyword', $keyword);
        }

        // 文章列表
        $topic = new Topic;
        $topicList = $topic->getTopicList($map, $page);
        // 关键字高亮替换
        // if (!empty($keyword)) 
        // {
        //     $topicList = $topicList->toArray()['data'];
        //     foreach ($topicList as $k => $v) 
        //     {
        //         $topicList[$k]['title'] = preg_replace("/($keyword)/i","<span class='highlight'>{$keyword}</span>", $v['title']);
        //     }
        // }

        // 热门帖子
        $hotList = $topic->getHotList();

        $this->assign('hotList', $hotList);
        $this->assign('topicList', $topicList);

        // 渲染首页模板
        return $this->fetch();
    }

}
