<?php
namespace app\frontend\controller;

use app\frontend\controller\Base;
use app\frontend\controller\Reply;
use app\model\TopicModel;
use think\facade\Cache;

/**
 * 帖子控制器
 */
class Topic extends Base
{
	/**
	 * ============================
	 * @Author:   PrintHzf
	 * @Version:  1.0 
	 * @DateTime: 2019-06-04
	 * @Description: 初始化
	 * ============================
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * ============================
	 * @Author:   PrintHzf
	 * @Version:  1.0 
	 * @DateTime: 2019-06-04
	 * @Description: 文章列表页
	 * ============================
	 */
	public function getTopicList($map=[], $page=1, $per=4)
	{
		// if (empty($map)) {			
		// 	$redis = Cache::store('redis');
		// 	if ($redis->has('topic:list')) {
		// 		// 从集合中拿出数据
		// 		$lists = $redis->lRange('lists', $begin, $page * $per);
		// 	}
		// }
		$begin = $per * ($page - 1);
		$limit = $begin != 0 ? "{$begin},{$per}" : $per;
		$list  = TopicModel::withJoin(['user'=>['username'],'category'=>['category_name']])
				->where($map)->order('gmt_create desc')
				->limit($limit)
				->paginate($per, false, ['query'=>request()->param()])
				->each(function($item, $key){
					$item->tags = explode(',', $item->tags);
					// 关键字高亮替换
					// $item->title = preg_replace("/($keyword)/i","<span class='highlight'>{$keyword}</span>", $item->title);
				});
		return $list;
	}

    /**
     * ============================
     * @Author:   PrintHzf
     * @Version:  1.0 
     * @DateTime: 2019-06-04
     * @Description: 文章内容详情页
     * ============================
     */
	public function veiwTopicDetail()
	{
		$id = $this->request->param('topic_id');
		show($id);exit;
		$map['id'] = $id;
		$field = 'id,title,username,gmt_create,view_count,reply_count,body,last_topic';
		$topic = TopicModel::alias('t')->withJoin(['user'=>['username']])
				->get(function($query) use ($map, $field) {
					$query->where($map)->field($field);
				});
		// 上一条记录的ID
		$param = [
			'field' => 'id',
			'map' => [
				'id' => ['<', $id],
			],
			'order' => 'id desc',
			'limit' => 1
		];
		$lastTopicId = topicService::read($param);
		$param['map'] =  ['id' => ['>', $id]];
		show($param);
		$newTopicId  = topicService::read($param);
		$reply = ReplyService::read();
		$this->assign('topic', $topic);
		return $this->fetch('topic_detail');
	}

	/**
	 * ============================
	 * @Author:   PrintHzf
	 * @Version:  1.0 
	 * @DateTime: 2019-06-04
	 * @Description: 文章编辑页
	 * ============================
	 */
	public function viewEdit()
	{
		return $this->fetch('topic_edit');
	}

	/**
	 * ============================
	 * @Author:   PrintHzf
	 * @Version:  1.0 
	 * @DateTime: 2019-06-04
	 * @Description: 获取热点文章
	 * ============================
	 */
	public function getHotList()
	{
		$list = TopicModel::all(function($query) {
			$query->field('id,title,gmt_create')
			->where('is_hot','1')
			->order('view_count','desc')
			->limit(12);
		}); 
		return $list;
	}

}