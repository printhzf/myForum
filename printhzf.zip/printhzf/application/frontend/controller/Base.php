<?php
namespace app\frontend\controller;

use app\model\UserModel;
use app\model\ReplyModel;
use app\model\TopicModel;
use app\frontend\controller\Category;
use think\Controller;

class Base extends Controller
{
    public function __construct()
    {
    	parent::__construct();
    	// $redis = Cache::store('redis');
    	// 导航栏文章分类
        $categoryTree = Category::getCategoryTree();
        // 帖子总数
        $topicCount = TopicModel::count();
        // 评论总数
        $replyCount = ReplyModel::count(); 
        // 用户总数
        $userCount  = UserModel::count(); 
        // TODO:在线用户数

        $this->assign('categoryTree', $categoryTree);
        $this->assign('topicCount', $topicCount);
        $this->assign('replyCount', $replyCount);
        $this->assign('userCount', $userCount);
    }
}