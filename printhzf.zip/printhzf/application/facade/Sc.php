<?php

namespace app\facade;
use think\Facade;

class Sc extends Facade
{
	protected static function getFacadeClass()
	{
		return 'app\util\Sc';
	}
}
