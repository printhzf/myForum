<?php
namespace app\http\middleware;

use think\facade\Session;
use think\auth\Auth;

/**
 * 权限校验
 */
class AuthMiddleware 
{
	// 无需校验的路由（全部小写）
	protected $exclude = [
		'index/user/viewlogin',
		'index/user/viewregister',
		'index/user/verify',
	];

	public function __construct()
	{
		# code...
	}

	public function handle($request, \Closure $next)
	{
		$module = $request->module();
        $controller = $request->controller();
        $action = $request->action();
        $rule = strtolower($module.'/'.$controller.'/'.$action);
        $auth = new Auth();
        if (!in_array($rule, $this->exclude)) 
        {
        	if (!$auth->check($rule, Session::get('userId'))) 
        	{
           		$this->error('没有访问权限');
        	}
        }
        return $next($request);
	}

}