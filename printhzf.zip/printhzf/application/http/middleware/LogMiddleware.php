<?php
namespace app\http\middleware;

use think\facade\Log;

/**
 * 访问记录
 */
class LogMiddleware 
{
	public function __construct()
	{
		# code...
	}

	public function handle($request, \Closure $next)
	{
		$response = $next($request);
		Log::write('动作结束');
        return $next($request);
	}

}