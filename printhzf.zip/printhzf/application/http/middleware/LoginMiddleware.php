<?php
namespace app\http\middleware;

use think\facade\Session;
use think\facade\Cookie;
use think\facade\Cache;
use app\facade\Sc;

/**
 * 登录校验
 */
class LoginMiddleware 
{
	public function __construct()
	{
		# code...
	}

	public function handle($request, \Closure $next)
	{
		if (Cookie::has('USER_INFO_COOKIE'))
		{
			$sid  = Cookie::get('USER_INFO_COOKIE');
			$user = Cookie::store('redis')->get($sid);
			$user = unserialize($user);
			$userInfo = [
				'id' => $user->id,
				'username' => $user->username,
				'headimg'  => $user->headimg,
			];
			if (!Session::has('USER_INFO_SESSION'))
			{
				Sc::setLogin(setToken());
				Sc::setUserInfo($userInfo);
				Sc::setUserRole(Access::get($user->id)['group_id']);
			} 
		} else {
			if (empty(Sc::getLogin()))
			{
				// return redirect('index/viewError');
			}
		}
        return $next($request);
	}

}