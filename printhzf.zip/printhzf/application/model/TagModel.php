<?php
namespace app\model;

use think\Model;

class TagModel extends Model
{
    // 默认主键
    protected $pk = 'id';  
    // 默认数据表
    protected $table = 'tag';

    // 关联文章模型
    public function topics()
    {
        return $this->belongsToMany('topic');
    }

}