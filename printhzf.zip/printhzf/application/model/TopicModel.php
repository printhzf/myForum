<?php 
namespace app\model;

use think\Model;
use think\facade\Cache;

class TopicModel extends Model 
{
	protected $pk = 'id';
	protected $table = 'topic';
	protected $createTime = 'gmt_create';
	protected $updateTime = 'gmt_modified';

	protected static function init()
	{
	// // 文章创建成功后将数据保存到Redis文章列表
	// self::event('after_insert', function ($event) {
	//   $redis->lPush('topic:list', $event);
	// });
	  
	// // 观看次数更新成功后将数据保存到Redis文章列表
	// self::event('ater_update', function ($event) {
	//   // 热门文章有序集合
	//   $redis->zAdd("topic:hot", $event->view_count, $event->id);
	// });
	}

	// --------------------获取器--------------------

	public function getBriefAttr($value)
	{
		return "{$value}...";
	}
	public function getStatusAttr($value)
	{
		$status = ['1'=>'显示', '0'=>'隐藏'];
		return $status[$value];
	}

	public function getViewCountAttr($value)
	{
		$status[$value] = convertNumber($value);
		return $status[$value];
	}

	public function getReplyCountAttr($value)
	{
		$status[$value] = convertNumber($value);
		return $status[$value];
	}

	// --------------------关联模型--------------------
	// 关联用户表（一对一）
	public function user()
	{
		return $this->belongsTo('UserModel', 'user_id');
	}

	// 关联分类表（一对一）
	public function category()
	{
		return $this->belongsTo('CategoryModel', 'category_id');
	}

	// 关联回复表（一对多）
	public function reply()
	{
		return $this->hasMany('ReplyModel');
	}
}