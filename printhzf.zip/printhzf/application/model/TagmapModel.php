<?php
namespace app\model;

use think\model\Pivot;

class TagmapModel extends Pivot
{
    // 默认主键
    protected $pk = 'id';  
    // 默认数据表
    protected $table = 'tag_map';
}