<?php 
namespace app\model;

use think\Model;

class CategoryModel extends Model 
{
	
	protected $pk = 'id';
	protected $table = 'category';
	// 创建时间字段
  	protected $createTime = 'gmt_create';
  	// 更新时间字段
    protected $updateTime = 'gmt_modified';
}