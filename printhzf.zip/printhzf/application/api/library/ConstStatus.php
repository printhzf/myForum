<?php

namespace app\api\library;

class ConstStatus 
{
    const ERROR   = 0;
    const SUCCESS = 200;
    // 通用类错误1
    const ERROR_TIMEOUT  = 10001;
    // 用户类错误2 
    const ERROR_CAPTCHA  = 20001;
    const ERROR_LOGIN    = 20002;
    const ERROR_USER_NO  = 20003;
    const ERROR_PASSWORD = 20004;
    const ERROR_USER_BAN = 20005;
}