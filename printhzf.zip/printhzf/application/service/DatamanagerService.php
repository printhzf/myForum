<?php

namespace app\service;
use think\Db;
use app\facade\File;

class DatamanagerService
{
	public function backup()
	{

	}

	public function restore()
	{

	}

	public function optimize()
	{

	}
}