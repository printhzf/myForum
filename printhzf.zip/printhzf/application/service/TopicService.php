<?php
namespace app\service;

use app\model\TopicModel;
use think\facade\Cache;

/**
 * 帖子行为类
 */
class TopicService
{
	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-15
	 * @Description: 初始化
	 * ============================
	 */
	public function _initialize()
	{
		
	}

	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-15
	 * @Description: 查询文章数据
	 * ============================
	 */
	public static function read($param)
	{

	}

	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-15
	 * @Description: 文章编辑
	 * ============================
	 */
	public static function edit($param)
	{

	}

	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-15
	 * @Description: 文章删除
	 * ============================
	 */
	public static function delete($map=[])
	{

	}


	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-15
	 * @Description: 初始化
	 * ============================
	 */
	public function list($map=[], $page=1, $per=4)
	{

	}

	public function hotList($limit)
	{

	}

	/**
	 * ============================
	 * @Author:   PrintHZF
	 * @Version:  1.0 
	 * @DateTime: 2019-07-15
	 * @Description: 初始化
	 * ============================
	 */
	public function detail($map=[], $field = '*')
	{

	}

}