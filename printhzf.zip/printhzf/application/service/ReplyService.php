<?php

namespace app\service;

use app\model\ReplyModel;

class ReplyService
{
	/**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 统计回复数
     * ============================
     */
    public static function count($map=[])
    {

    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-18
     * @Description: 查询回复数据
     * ============================
     */
    public static function read($param=[])
    {

    }
}