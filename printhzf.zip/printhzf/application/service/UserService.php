<?php

namespace app\service;

use app\api\library\ConstStatus;
use app\model\UserModel;
use think\facade\Session;
use think\facade\Request;
use app\facade\Sc;
use Redis;

class UserService
{
    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-15
     * @Description: 用户列表
     * ============================
     */
    public function list()
    {
        return UserModel::all();
    }

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 用户编辑
     * ============================
     */
    public function edit($param)
    {
        return UserModel::allowField(true)->save($param);
    }

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 用户删除
     * ============================
     */
    public function delete($map)
    {
        return UserModel::destroy(function($query) use ($map) {
            $query->where($map);
        });
    }

	/**
     * @Author:      Hzf
     * @DateTime:    2019-05-09
     * @Description: 生成验证码
     */
    public function verify($config)
    {
        $captcha = new \think\captcha\Captcha($config);
        return $captcha->entry();
    }

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 用户登录
     * ============================
     */
	public function login($param) 
	{
        $verify   = $param['verify'];
        $username = $param['username'];
        $password = $param['password'];
        $captcha = new Captcha();
        if (!$captcha->check($verify)) 
        {
            return ConstStatus::ERROR_CAPTCHA;
        } 
		$user = UserModel::where('username', $username)->find();
		if (!$user) 
        {
			return ConstStatus::ERROR_NO_USER;
		}
		if ($user->status != 1) 
        {
			return ConstStatus::ERROR_BAN_USER;
		}
		if (!$this->loginVerify($user, $password)) 
        {
			return ConstStatus::ERROR_PASSWORD;
		}
		return ConstStatus::SUCCESS;
	}

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 用户登录校验
     * ============================
     */
	public function loginVerify($user, $password) 
	{
		if (md5($password) == $user->password) 
        {
            // 存储用户信息
            // $this->initLogin($user);
			Sc::setUserInfo($user);
            // 修改用户登录信息
            $user->last_login_time = time();
            $user->last_login_ip   = $_SERVER["REMOTE_ADDR"];
            if ($user->save()) 
            {
				return true;
            }
		}
		return false;
	}

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 用户登录初始化
     * ============================
     */
    public function initLogin($user) 
    {
        $data = [
            'userId'   => $user->id,
            'userName' => $user->username,
            'userImg'  => $user->headimg,
        ];
        // 将用户信息存储Session
        Session::set('userInfo', $data);
    }

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 统计用户数
     * ============================
     */
    public static function count($map=[])
    {
        return UserModel::where($map)->count();
    }

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 获取用户列表
     * ============================
     */
	public function userList($limit, $page, $condition) 
    {
        $map      = [];
        $data     = [];
        $begin    = ($page-1)*$limit;
        $ip       = $condition['last_login_ip'];
        $gid      = $condition['group_id'];
        $status   = $condition['status'];
        $username = $condition['username'];
        if (!empty($ip)) {
            $map['last_login_ip'] = ['like',"%{$ip}%"];
        }
        if (!empty($status)) {
            $map['status'] = $status;
        }
        if (!empty($username)) {
            $map['username'] = ['like',"%{$username}%"];
        }
        $userArr = UserModel::with(['roles' => function($query) use ($gid) {
            if (!empty($gid)) {
                $query->field('title')->where('id', $gid);
            } else {
                $query->field('title');
            }
        }])->where(new where($map))->limit($begin, $limit)->all()->toArray();
        if (!empty($userArr)) {             
            foreach ($userArr as $k => $user) {
                if (!empty($user['roles'])) {
                    $title  = ['role' => $user['roles'][0]['title']];
                    $data[] = array_merge($user, $title);
                }
            }
        } else {
            $data = $userArr;
        }
        return showLayuiTableMsg(count($data), $data);
    }

    // 获取用户数据
    public function userInfo($userId)
    {
        // $redis = new Redis();
        // $redis->connect('127.0.0.1', 6379);
        // $this->redis->auth('password');
        $redis = Cache::store('redis');
        // 缓存存在直接返回缓存
        if ($data = $redis->get("user:{$user_id}")) 
        {
            return $data;
        }
        // 如果抢占失败再读取一次缓存
        if (!$redis->setnx('lock', 1)) {
            sleep(1);
            $data = $redis->get("user:{$user_id}");
        } else {
            $data = Db::name('user')->where('id', $user_id)->find();
            // 缓存数据
            $redis->set('user:{$user_id}', $data);
            // 释放锁
            $redis->delete('lock');
        }
        return $data;
    }

     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-17
     * @Description: 退出登录
     * ============================
     */
    public function logout()
    {
         // 1.删除redis的用户信息
        // $userId= Session::get('userId');
        // $redis = new Redis();
        // $redis->connect('127.0.0.1', 6379);
        // $redis->del("user:{$userId}");
        // 2.清除session/cookie的用户信息
        Cookie::delete('USER_INFO_COOKIE');
        Session::delete('USER_INFO_SESSION');
        // 3.退出登录并跳转到首页面
        $this->redirect('/index');
    }
}