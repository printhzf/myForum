<?php
namespace app\service;

use app\model\CategoryModel;
use think\facade\Cache;

/**
 * 分类行为类
 */
class CategoryService
{
    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-15
     * @Description: 分类列表
     * ============================
     */
    public function list()
    {

    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-15
     * @Description: 分类编辑
     * ============================
     */
	public function edit($param)
    {

    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-15
     * @Description: 分类删除
     * ============================
     */
    public function delete($map=[])
    {

    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-15
     * @Description: 树结构分类
     * ============================
     */
    public static function tree()
    {

    }


     /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-15
     * @Description: 获取上级分类
     * ============================
     */
    public function breadcrumbs($categoryId)
    {

    }
}