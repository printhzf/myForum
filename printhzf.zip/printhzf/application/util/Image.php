<?php
namespace app\util;

class Image 
{
    // 上传图片
    public function upload($file) 
    {
        // $file = Request::file('file');
        if (!empty($file)) {  
            $validate = [
                'size' => 1567800,
                'ext'  => 'jpg,png,gif'
            ];
            // 将文件移动到框架应用目录/public/upload/ 目录下
            $info = $file->validate($validate)->move('uploads/'); 
            if($info) {
                $res = ['errno' => 0, 'data' =>'uploads/'.$info->getSaveName()]; //文件的位置以及文件名
            } else {
                $res = ['errno' => 200, 'data' =>$file->getError()];
            } 
        } else {
            $res = ['errno' => 0, 'data' =>'请上传图片'];
        }
        return json($res);
    }

    // 添加水印
    public function addWater($path) 
    {
        // $path = Request::param('path');
    	// $path = $request->file('image');
        $image = \think\Image::open($path);
        if ($image) 
        {    	
	    	$dir = dirname($path);
	    	$base= basename($path);
	    	$newDir = "{$dir}/water_/";
	    	$file= "water_{$base}";
	        // 给原图右下角添加透明度为50的水印
			$image->water($path, \think\Image::WATER_SOUTHEAST, 50)->save($newDir.$file);
        }
    }

    // 图片裁剪
    public function crop($info) 
    {
        $path  = $info['path']; 
        $image = \think\Image::open($path);
    	if ($image) 
        { 
	    	$dir  = dirname($path);
	    	$base = basename($path);
	    	$newDir = "{$dir}/crop/";
	    	$file = "crop_{$base}";
	        // 将图片裁剪为300x300并保存为crop.png
			$image->crop($info['width'], $info['height'])->save($newDir.$file);
		}
    }
    
    // 删除图片
    public function delete($path)
    {
        if (file_exists($path)) {         
            if (unlink($path)) {
                $res = ['code' => 200, 'msg'=> '删除成功'];
            } else {
                $res = ['code' => 0, 'msg'=> '删除失败'];
            }
        } else {
            $res = ['code' => 0, 'msg'=> '目录不存在']
        }
        return json($res);
    }
}
