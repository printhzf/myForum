<?php

namespace app\backend\controller;

use think\Controller;
use app\Service\DatamanagerService;
use app\Service\AnalysisService;

/** 
 * api管理
 */
class Apimanager extends Controller
{

}