<?php

namespace app\backend\controller;

use think\Controller;
use app\Service\DatamanagerService;
use app\Service\AnalysisService;

/** 
 * 常用工具控制器
 */
class Tool extends Controller
{
	/**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-18
     * @Description: 
     * ============================
     */
	public function index()
    {
        return $this->fetch();
    }


    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-18
     * @Description: 规范文档
     * ============================
     */
    public function viewDoc()
    {
        return $this->fetch('doc');
    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-18
     * @Description: UI素材
     * ============================
     */
    public function viewUi()
    {
        return $this->fetch('ui');
    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-18
     * @Description: 数据管理
     * ============================
     */
    public function viewDataManager()
    {
        // 数据备份、压缩、还原、优化、修复
        return $this->fetch('dms');
    }

    /**
     * ============================
     * @Author:   PrintHZF
     * @Version:  1.0 
     * @DateTime: 2019-07-18
     * @Description: 数据分析
     * 1.查看整体情况指标卡、个表情况、表间关系、数据可视化展示
     * 2.任意筛选多个字段生成自定义图表
     * 3.查看慢查询语句
     * ============================
     */
    public function viewAnalysis()
    {
		$analysis = new AnalysisService();
    	// 整体指标（数据库个数、表个数、所占磁盘容量）
    	$sizeInfo = $analysis->getSizeInfo();
    	$database = $analysis->getDatabase();
    	$table    = $analysis->getTable();
    	$column   = $analysis->getColumn();
        // 性能指标（QPS、TPS、key Buffer命中率、InnoDB Buffer命中率、Query Cache命中率、Table Cache状态量、Thread Cache命中率、锁定状态、复制延时量、Tmp Table 状况、Binlog Cache 使用状况、Innodb_log_waits 量、open file and table）
    	return $this->fetch('analysis');
    }
}
