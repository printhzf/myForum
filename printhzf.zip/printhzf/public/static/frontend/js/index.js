//获取滚动条当前的位置 
function getScrollTop() { 
	var scrollTop = 0; 
	if (document.documentElement && document.documentElement.scrollTop) { 
		scrollTop = document.documentElement.scrollTop; 
	} 
	else if (document.body) { 
		scrollTop = document.body.scrollTop; 
	} 
	return scrollTop; 
};

//获取当前可是范围的高度 
function getClientHeight() { 
	var clientHeight = 0; 
	if (document.body.clientHeight && document.documentElement.clientHeight) { 
		clientHeight = Math.min(document.body.clientHeight, document.documentElement.clientHeight); 
	} 
	else { 
		clientHeight = Math.max(document.body.clientHeight, document.documentElement.clientHeight); 
	} 
	return clientHeight; 
};

//获取文档完整的高度 
function getScrollHeight() { 
	return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight); 
};

// 置顶
$("#gotop").click(function () {
    var speed=200;//滑动的速度
    $('body,html').animate({ scrollTop: 0 }, speed);
    return false;
});

// 置底
$("#godown").click(function () {
	var height = getScrollHeight();
    var speed=200;//滑动的速度
    $('body,html').animate({ scrollTop: height }, speed);
    return false;
});

// 图片放大

// 皮肤css
var skinCss = document.getElementById("skin");
// 换肤
$(".changeSkin").click(function(){
	event.stopPropagation();
	var skinName = $(this).attr('skinName');
	skinCss.href = '../css/' + skinName + '.css';
	// 保存肤色名
	setStorage('skinName', skinName);
});

$(function(){

	//访问本地存储，获取皮肤名
	var skinName = getStorage("skinName");
	//判断是否有皮肤名，就使用获取的皮肤名，没有就用默认的
	if (skinName && skinName != null) {
		skinCss.href = '../css/' + skinName + '.css';
	} else {
		$("#skin").attr("href",'../css/default.css');
	}

	// 导航栏添加三角标签
	$('.nav-list>li').each(function(){
		if ($(this).children('ul').length >0)
		{
			var i = $(this).find('i');
			i.addClass('fa-sort-up');
		}
	});

	// 导航栏鼠标悬停事件
	$('.nav-list>li').hover(function(){
 		$(this).css('border-bottom','6px solid #1cbb9b');
 		var i = $(this).find('.fa-sort-up');
 		i.css('top', '18px');
 		i.addClass('fa-sort-down');
 		i.removeClass('fa-sort-up');
 		$(this).find('.nav-children').show();
	},function(){
		var i = $(this).find('.fa-sort-down');
 		i.css('top', '26px');
 		i.removeClass('fa-sort-down');
 		i.addClass('fa-sort-up');
 		$(this).find('.nav-children').hide();
		$(this).css('border-bottom','0');
	});
});

var storage = window.localStorage;
// 写入localStorage
function setStorage(name, val) 
{
	if (storage) {
        storage.setItem(name, val);
    } 
    return false;
}
// 读取localStorage
function getStorage(name) 
{
	if (storage) {
        var val = storage.getItem(name);
		return val;
    } 
	return false;
}
// 删除localStorage的指定键值对删除
function delStorage(name)
{
	if (storage) {
		storage.removeItem(name);
	}
}
// 清空localStorage
function clearStorage()
{
	if (storage) {
		storage.clear();
	}
}
