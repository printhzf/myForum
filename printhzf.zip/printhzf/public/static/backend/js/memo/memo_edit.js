layui.use(['form', 'layedit', 'laydate'], function(){
	var form = layui.form
	,layer = layui.layer
	,layedit = layui.layedit
	,laydate = layui.laydate;
	// 建立日期选择器
	laydate.render({
		elem : '#deadline'
		,type: 'datetime'
		// ,value: new Date()
	});
	// 监听提交按钮
	form.on('submit(save)', function(data){
		var data = $("#memoForm").serialize();
		$.ajax({
			type : 'post',
			url  : '../savememo',
			data : data,
			success: function(res) {
				layer.msg(res.msg, {time: 1200}, function(){
					parent.parent.initClock();	
					if (res.code == 200) {	
						var index = parent.layer.getFrameIndex(window.name); //获取窗口索引
						parent.layer.close(index);
						parent.document.getElementById("refreshBtn").click();
					}
				});
			}
		});
		return false;
	});
	// 监听重置按钮
	form.on('submit(reset)', function(data){
		$('memoForm')[0].reset();
		return false; 
	});
});
