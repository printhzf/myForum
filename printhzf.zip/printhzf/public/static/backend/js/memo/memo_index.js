layui.use('laydate', function(){
	var laydate = layui.laydate;
	
	//日期时间范围选择
	laydate.render({ 
		elem  : '#datetimeRange'
		,type : 'datetime'
		,range: '~'
	});
});

// 编辑备忘录
$(".editBtn").click(function(){
	var mid   = $(this).parent().parent().attr('mid');
	if (mid == '' || mid == undefined) {
		mid = 0;
	}
	var title = '备忘录';
	var url   = 'backend/editmemo/'+mid; 
	var index = parent.layer.open({
		type : 2
		,title : title
		,shadeClose: true
		,area : ['500px','500px']
		,fixed : false //不固定
		,content : url
		,end : function() {}
	});
});

// 删除备忘录
$(".deleteBtn").click(function() {
	var mid = $(this).parent().parent().attr('mid');
	var str = '是否确定删除？';
	layer.confirm(str, {btn: ['确定', '取消'], title: "提示"}, function () {
		$.ajax({
			type : 'POST'
			,data : {'id' : mid}
			,url  : 'backend/delmemo' 
			,success : function(res) {
				layer.msg(res.msg, {time: 1200}, function(){
					if (res.code == 200) {	
						parent.cleanAllClock();
						parent.initClock();
						window.location.reload();
					}
				});
			}
		});
	});
});

// 置顶备忘录
$(".stickBtn").click(function() {
	var id = $(this).parent().parent().attr('mid');
	var is_top = $(this).attr('is_top');
	var url = 'backend/setstick/'+ id + '/' + is_top;
	$.ajax({
		type : 'GET'
		,url : url
		,success : function(res) {
			layer.msg(res.msg, {time: 1200}, function(){
				if (res.code == 200) {	
					window.location.reload();
				}
			});
		}
	});
});

$(".toolBox").each(function(){
	$(this).hover(function(){
		var id = $(this).attr('mid');
		$("#toolBar"+id).show();
		$("#moreBtn"+id).hide();
	},function(){
		var id = $(this).attr('mid');
		$("#moreBtn"+id).show();
		$("#toolBar"+id).hide();
	});
});