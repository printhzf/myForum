// layui.use(['element','layer'], function(){
//     var element = layui.element,
//     	layer   = layui.layer;
//     var active={
//     	// 新增一个Tab项 传入三个参数，分别对应其标题，tab页面的地址，还有一个规定的id，是标签中data-id的属性值
//         // 关于tabAdd的方法所传入的参数可看layui的开发文档中基础方法部分
//         tabAdd:function(url,id,name){
//             element.tabAdd('contentnav',{
//                 title:name,
//                 content:'<iframe id="iframe'+id+'" data-frameid="'+id+'" scrolling="auto" frameborder="0" src="'+url+'" width="100%"></iframe>',
//                 id:id // 规定好的id
//             });
//             rightMenu(); // 给tab绑定右击事件
//             iframeWH();  // 计算ifram层的大小
//         },
//         tabChange:function(id){
//         	// 切换到指定Tab项
//             element.tabChange('contentnav',id);  // 根据传入的id传入到指定的tab项
//         },
//         tabDelete:function(id){
//             element.tabDelete('contentnav',id); // 删除
//         },
//         tabDeleteAll:function(ids){ // 删除所有
//             $.each(ids,function(index,item){ 
//                 element.tabDelete('contentnav',item);
//             });
//         }
//     };

//     element.on('nav(treenav)', function(elem){
//         // 折叠其他同级菜单
//         elem.parent().siblings().removeClass('layui-nav-itemed')
//     });

//     // 切换侧边栏显示隐藏
//     var is_show = true;
//     $("#flexible-btn").on('click',function(){
//         var w = $(document.body).width();
//     	if (is_show) {
//             // 修改图标
//             $('#flexible-btn').removeClass('fa-outdent');
//             $('#flexible-btn').addClass('fa-indent');
//             // 隐藏侧边导航栏
//             $('.layui-nav-side').width(0);
//             // 主体内容全屏展示
//             $("#topMenu").width(w); 
//             $(".main").width(w);    
//             is_show = false;
//         } else {
//             $('#flexible-btn').removeClass('fa-indent');
//             $('#flexible-btn').addClass('fa-outdent');
//     		$('.layui-nav-side').width(200);
//     		$("#topMenu").width(w-200);	
//     		$(".main").width(w-200);	
//     		is_show = true;
//     	}	
//         $("body").toggleClass('big-page');
//         return false;
// 	});

//     // 刷新iframe
//     $("#refresh-btn").click(function(){
//         var id  = $('.layui-this').find('a').attr("data-id"); 
//         var src = $('.layui-this').find('a').attr("data-url"); 
//         $("#iframe"+id).attr('src', src);
//     });

// 	//当点击有site-url属性的标签时，即左侧菜单栏中内容 ，触发点击事件
//     $(".site-url").on('click',function(){
//         var nav=$(this);
//         var length = $("ul.layui-tab-title li").length;
//         if(length<=0){
//         	// 如果比零小，则直接打开新的tab项
//             active.tabAdd(nav.attr("data-url"),nav.attr("data-id"),nav.attr("data-title"));
//         }else{
//         	// 否则判断该tab项是否以及存在
//             var isData=false; //初始化一个标志，为false说明未打开该tab项 为true则说明已有
//             $.each($("ul.layui-tab-title li"),function(){
//             	// 如果点击左侧菜单栏所传入的id 在右侧tab项中的lay-id属性可以找到，则说明该tab项已经打开
//                 if($(this).attr("lay-id")==nav.attr("data-id")){
//                     isData=true;
//                 }
//             });
//             if(isData==false){
//             	// 标志为false 新增一个tab项
//                 active.tabAdd(nav.attr("data-url"),nav.attr("data-id"),nav.attr("data-title"));
//             }
//             // 最后不管是否新增tab，最后都转到要打开的选项页面上
//             active.tabChange(nav.attr("data-id"));
//         }
//     });

//     $(window).resize(function(){
//         iframeWH();
//     });

//     function iframeWH() {
//         var H = $(window).height() - 136;
//         $("iframe").css("height", H + "px");
//     }

// }); 

// 右键菜单
// function rightMenu(){
//     // 右击弹出
//     $(".layui-tab-title li").on('contextmenu',function(e){
//         var menu=$(".rightmenu");
//         menu.find("li").attr('data-id',$(this).attr("lay-id"));
//         l = e.clientX-180;
//         t = e.clientY-60;
//         menu.css({ left:l, top:t}).show();
//         return false;
//     });
//     // 左键点击隐藏
//     $("body,.layui-tab-title li").click(function(){
//         $(".rightmenu").hide();
//     });
// }

// $(".rightmenu li").click(function(){
//     if ($(this).attr("data-type")=="closethis") {
//         active.tabDelete($(this).attr("data-id"));
//     } else if($(this).attr("data-type")=="closeall") {
//         var tabtitle = $(".layui-tab-title li");
//         var ids = new Array();
//         tabtitle.each(function(i){
//             ids.push($(this).attr("lay-id"));
//         });
//         // 如果关闭所有 ，即将所有的lay-id放进数组，执行tabDeleteAll
//         active.tabDeleteAll(ids);
//     }
//     $('.rightmenu').hide(); // 最后再隐藏右键菜单
// });



$(function(){
	initClock();
});

// 获取新token并存入隐藏域
function getNewToken() {
    $.get('token', function(data) {
        $("input[name='__token__']").val(data);
    });
}

// 初始化定时提醒闹钟
function initClock() {
    // var url = $("input[name='hidden-url-clock']").val();
    var url = 'clock';
	$.ajax({
		async   : false,
		type    : 'GET',
		url     : url,
        before  : function() {},
        success : function(res) {
            window.clocks = res.msg;
            if (res.code == 200) {
                cleanAllClock();
				// for (var i in clocks) {
				//     clearTimeout(clocks[i]);
				// }
				$.each(res.msg, function(i,val){
					var varname = val.clockname;
					window[varname]  = window.setTimeout(function(){
						showMsg(val.content);
					}, val.clocktime);
					// window.clearTimeout(val.clockname);
					// val.clockname = window.setTimeout(function(){
					// 	showMsg(val.content);
					// }, val.clocktime);
				});
			}
		}
	});
}

// 清除全部定时器
function cleanAllClock() {
	var end = setTimeout(function(){},1);
	var start = (end -100)>0 ? end-100 : 0;
	for (var i=start;i<=end;i++) {
	    clearTimeout(i);
	}
}

// 备忘录内容弹窗提示
function showMsg(msg) {
	// var left =  $(window).width() - 200 + 'px';
	// var top  =  $(window).height() - y + 'px';
	var content = '<div style="padding: 20px 80px;">'+msg+'</div>';
	//边缘弹出
	layer.open({
		type: 1
		,area: ['200px', '200px']
		// ,offset: [top, left]
		,offset: 'rb' //具体配置参考：offset参数项
		,content: content
		,btn: '关闭全部'
		,btnAlign: 'c' //按钮居中
		,shade: 0 //不显示遮罩
		,yes: function(){
			layer.closeAll();
		}
	});
}
