require(['/wangEditor.min.js'], function (E) {
    var editor2 = new E('#div3')
    editor2.create()
})