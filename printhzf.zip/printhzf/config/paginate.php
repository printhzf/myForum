<?php 
return [
	'type' => 'page\Page',
	'var_page' => 'page', 
];
